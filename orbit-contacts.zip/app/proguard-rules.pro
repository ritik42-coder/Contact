# Orbit Contacts: default Android + Compose rules are enough.
-dontwarn java.lang.invoke.StringConcatFactory
