@file:OptIn(ExperimentalFoundationApi::class)

package com.orbit.contacts

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun InfoCard(icon: ImageVector, label: String, value: String, i: Int, key: Any, onClick: (() -> Unit)? = null, onLong: (() -> Unit)? = null) {
    val pal = LocalPal.current
    Glass(
        Modifier.enter(i, key).padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth()
            .then(if (onClick != null) Modifier.bounce(onLong = onLong, onClick = onClick) else Modifier), 20.dp
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(pal.acc.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = pal.acc, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(label, color = pal.sub, fontSize = 12.sp)
                Text(value, color = pal.text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
fun DetailScreen(vm: ContactsVm, id: Long, onBack: () -> Unit, onEdit: (Contact) -> Unit) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val c = vm.contacts.firstOrNull { it.id == id }
    if (c == null) {
        LaunchedEffect(vm.contacts) { delay(500); if (vm.contacts.none { it.id == id }) onBack() }
        Box(Modifier.fillMaxSize())
        return
    }
    val state = rememberLazyListState()
    val inset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val scroll = remember { derivedStateOf { if (state.firstVisibleItemIndex > 0) 600f else state.firstVisibleItemScrollOffset.toFloat() } }
    var confirmDelete by remember { mutableStateOf(false) }
    var tagDialog by remember { mutableStateOf(false) }
    val burst = remember { Animatable(0f) }
    val tags = vm.tagsOf(c)
    val hist = remember(c.id, vm.calls) { vm.callsFor(c) }
    var showQr by remember { mutableStateOf(false) }
    val inf = rememberInfiniteTransition(label = "hero")
    val rot by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "r")
    val glow by inf.animateFloat(0.35f, 0.8f, infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "g")

    Box(Modifier.fillMaxSize()) {
        LiveBackground { scroll.value }
        LazyColumn(state = state, contentPadding = PaddingValues(top = inset + 60.dp, bottom = 48.dp + navInset)) {
            item {
                Column(
                    Modifier.fillMaxWidth().graphicsLayer {
                        val s = scroll.value
                        translationY = s * 0.45f
                        alpha = (1f - s / 520f).coerceIn(0f, 1f)
                        scaleX = 1f - s / 2600f; scaleY = scaleX
                    }.padding(top = 8.dp, bottom = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.size(176.dp).enter(0, c.id), contentAlignment = Alignment.Center) {
                        Box(
                            Modifier.matchParentSize().graphicsLayer { rotationZ = rot }
                                .drawBehind { drawCircle(Brush.sweepGradient(listOf(pal.acc, pal.acc2, pal.acc)), size.minDimension * 0.43f, center, style = Stroke(4.dp.toPx())) }
                        )
                        if (pal.dark) Box(Modifier.matchParentSize().graphicsLayer { alpha = glow }.background(Brush.radialGradient(listOf(pal.acc.copy(alpha = 0.5f), Color.Transparent))))
                        Avatar(c, 136.dp)
                    }
                    Spacer(Modifier.height(14.dp))
                    Text(c.name.ifBlank { "(No name)" }, color = pal.text, fontSize = 30.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, modifier = Modifier.enter(1, c.id).padding(horizontal = 24.dp))
                    val sub = listOf(c.title, c.org).filter { it.isNotBlank() }.joinToString(" · ")
                    if (sub.isNotBlank()) Text(sub, color = pal.sub, fontSize = 15.sp, modifier = Modifier.enter(2, c.id))
                    vm.lastTalk[c.id]?.let { Text("Last talked ${ago(it)} ago", color = pal.acc, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.enter(2, c.id).padding(top = 2.dp)) }
                }
            }
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    val num = c.phones.firstOrNull()?.number
                    val mail = c.emails.firstOrNull()?.address
                    ActionBtn(Icons.Rounded.Call, "Call", Color(0xFF22C55E), 3, c.id, num != null) { callNum(ctx, num!!) }
                    ActionBtn(Icons.Rounded.Sms, "Message", Color(0xFF3B82F6), 4, c.id, num != null) { smsNum(ctx, num!!) }
                    ActionBtn(Icons.Rounded.Chat, "WhatsApp", Color(0xFF14B8A6), 5, c.id, num != null) { whatsapp(ctx, num!!) }
                    ActionBtn(Icons.Rounded.Email, "Email", Color(0xFFF59E0B), 6, c.id, mail != null) { mailTo(ctx, mail!!) }
                }
            }
            var n = 7
            for (p in c.phones) { val k = n++; item {
                Glass(Modifier.enter(k, c.id).padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth().bounce(onLong = { copyText(ctx, p.number) }) { callNum(ctx, p.number) }, 20.dp) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(phoneLabel(p.type), color = pal.acc, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(p.number, color = pal.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        }
                        IconBtn(Icons.Rounded.Sms) { smsNum(ctx, p.number) }
                        Spacer(Modifier.width(8.dp))
                        IconBtn(Icons.Rounded.Call, filled = true) { callNum(ctx, p.number) }
                    }
                }
            } }
            for (e in c.emails) { val k = n++; item { InfoCard(Icons.Rounded.Email, mailLabel(e.type), e.address, k, c.id, { mailTo(ctx, e.address) }, { copyText(ctx, e.address) }) } }
            if (c.birthday.isNotBlank()) { val k = n++; item {
                val d = daysToBirthday(c.birthday)
                InfoCard(Icons.Rounded.Cake, "Birthday" + (if (d != null) " · " + (if (d == 0) "today!" else "in $d days") else ""), c.birthday.removePrefix("--"), k, c.id)
            } }
            if (c.org.isNotBlank()) { val k = n++; item { InfoCard(Icons.Rounded.Business, "Work", listOf(c.org, c.title).filter { it.isNotBlank() }.joinToString(" — "), k, c.id) } }
            if (c.address.isNotBlank()) { val k = n++; item { InfoCard(Icons.Rounded.LocationOn, "Address", c.address, k, c.id, { openMap(ctx, c.address) }) } }
            if (c.website.isNotBlank()) { val k = n++; item { InfoCard(Icons.Rounded.Language, "Website", c.website, k, c.id, { openUrl(ctx, c.website) }) } }
            if (c.note.isNotBlank()) { val k = n++; item { InfoCard(Icons.Rounded.Notes, "Notes", c.note, k, c.id) } }
            if (hist.isNotEmpty()) { val k = n++; item { HistoryCard(hist, k, c.id) } }
            item {
                Column(Modifier.enter(n, c.id).padding(horizontal = 20.dp, vertical = 10.dp)) {
                    Text("TAGS", color = pal.sub, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(tags) { t ->
                            Row(
                                Modifier.clip(RoundedCornerShape(16.dp)).background(pal.acc.copy(alpha = 0.16f)).bounce { vm.setTags(c, tags - t) }.padding(horizontal = 12.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(t, color = pal.acc, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Spacer(Modifier.width(4.dp))
                                Icon(Icons.Rounded.Close, null, tint = pal.acc, modifier = Modifier.size(14.dp))
                            }
                        }
                        item {
                            Row(
                                Modifier.clip(RoundedCornerShape(16.dp)).background(pal.card).border(1.dp, pal.line, RoundedCornerShape(16.dp)).bounce { tagDialog = true }.padding(horizontal = 12.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Rounded.Add, null, tint = pal.sub, modifier = Modifier.size(16.dp))
                                Text(" Tag", color = pal.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
            item {
                Box(Modifier.fillMaxWidth().padding(top = 18.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "Delete contact", color = Color(0xFFEF4444), fontWeight = FontWeight.Bold,
                        modifier = Modifier.clip(RoundedCornerShape(20.dp)).border(1.dp, Color(0x55EF4444), RoundedCornerShape(20.dp)).bounce { confirmDelete = true }.padding(horizontal = 24.dp, vertical = 12.dp)
                    )
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(top = inset + 8.dp, start = 12.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(Icons.AutoMirrored.Rounded.ArrowBack) { onBack() }
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.size(44.dp).drawBehind {
                    val t = burst.value
                    if (t > 0.01f && t < 0.99f) for (k in 0 until 10) {
                        val a = k * 0.628f
                        val r = t * 62.dp.toPx()
                        drawCircle(Color(0xFFFFC53D), 5.dp.toPx() * (1f - t), center + Offset(cos(a) * r, sin(a) * r), alpha = 1f - t)
                    }
                }, contentAlignment = Alignment.Center
            ) {
                IconBtn(if (c.starred) Icons.Rounded.Star else Icons.Rounded.StarBorder, tint = if (c.starred) Color(0xFFFFC53D) else null) {
                    if (!c.starred) scope.launch { burst.snapTo(0f); burst.animateTo(1f, tween(650)) }
                    vm.star(listOf(c), !c.starred)
                }
            }
            Spacer(Modifier.width(8.dp))
            IconBtn(Icons.Rounded.QrCode) { showQr = true }
            Spacer(Modifier.width(8.dp))
            IconBtn(Icons.Rounded.Share) { shareVcard(ctx, c) }
            Spacer(Modifier.width(8.dp))
            IconBtn(Icons.Rounded.Edit, filled = true) { onEdit(c) }
        }
        QrOverlay(showQr, c) { showQr = false }
    }

    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Delete ${c.name.ifBlank { "contact" }}?") },
        text = { Text("You can undo right after.") },
        confirmButton = { TextButton({ confirmDelete = false; vm.delete(listOf(c)); onBack() }) { Text("Delete", color = Color(0xFFEF4444)) } },
        dismissButton = { TextButton({ confirmDelete = false }) { Text("Cancel") } }
    )
    if (tagDialog) {
        var t by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { tagDialog = false },
            title = { Text("New tag") },
            text = {
                BasicTextField(t, { t = it.take(16) }, singleLine = true, textStyle = TextStyle(fontSize = 18.sp, color = pal.text), cursorBrush = SolidColor(pal.acc),
                    decorationBox = { inner -> Box(Modifier.fillMaxWidth().border(1.dp, pal.line, RoundedCornerShape(12.dp)).padding(12.dp)) { if (t.isEmpty()) Text("Family, Work, College…", color = pal.sub); inner() } })
            },
            confirmButton = { TextButton({ val x = t.trim().replace(",", ""); if (x.isNotEmpty() && x !in tags) vm.setTags(c, tags + x); tagDialog = false }) { Text("Add") } },
            dismissButton = { TextButton({ tagDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun ActionBtn(icon: ImageVector, label: String, color: Color, i: Int, key: Any, enabled: Boolean, onClick: () -> Unit) {
    val pal = LocalPal.current
    Column(Modifier.enter(i, key).graphicsLayer { alpha = if (enabled) 1f else 0.35f }, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(58.dp).clip(CircleShape).background(Brush.linearGradient(listOf(color, color.copy(alpha = 0.7f))))
                .bounce { if (enabled) onClick() }, contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(26.dp)) }
        Spacer(Modifier.height(6.dp))
        Text(label, color = pal.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Clip)
    }
}
