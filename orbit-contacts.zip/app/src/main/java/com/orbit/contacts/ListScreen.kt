@file:OptIn(ExperimentalFoundationApi::class)

package com.orbit.contacts

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Cake
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Dialpad
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Sms
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

fun highlight(text: String, q: String, hi: Color): AnnotatedString = buildAnnotatedString {
    val s = q.trim()
    val i = if (s.isEmpty()) -1 else text.lowercase().indexOf(s.lowercase())
    if (i < 0) append(text) else {
        append(text.substring(0, i))
        withStyle(SpanStyle(color = hi, fontWeight = FontWeight.Bold)) { append(text.substring(i, i + s.length)) }
        append(text.substring(i + s.length))
    }
}

@Composable
fun SearchPill(q: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val pal = LocalPal.current
    var focused by remember { mutableStateOf(false) }
    val g by animateFloatAsState(if (focused) 1f else 0f, tween(300), label = "sg")
    val sh = RoundedCornerShape(26.dp)
    Row(
        modifier.fillMaxWidth().height(52.dp).clip(sh).background(pal.card)
            .border(1.5.dp, Brush.linearGradient(listOf(pal.acc.copy(alpha = 0.12f + 0.88f * g), pal.acc2.copy(alpha = 0.08f + 0.7f * g))), sh)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Search, null, tint = lerp(pal.sub, pal.acc, g), modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            if (q.isEmpty()) Text("Search name, number or T9…", color = pal.sub, fontSize = 16.sp, maxLines = 1)
            BasicTextField(
                q, onChange, singleLine = true,
                textStyle = TextStyle(color = pal.text, fontSize = 16.sp), cursorBrush = SolidColor(pal.acc),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                modifier = Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused }
            )
        }
        AnimatedVisibility(q.isNotEmpty(), enter = scaleIn() + fadeIn(), exit = scaleOut() + fadeOut()) {
            Icon(Icons.Rounded.Close, null, tint = pal.sub, modifier = Modifier.size(24.dp).bounce { onChange("") })
        }
    }
}

@Composable
fun LetterHeader(ch: Char, count: Int = 0) {
    val pal = LocalPal.current
    Box(
        Modifier.fillMaxWidth()
            .background(Brush.verticalGradient(listOf(pal.bg.copy(alpha = 0.94f), pal.bg.copy(alpha = 0f))))
            .padding(start = 26.dp, end = 20.dp, top = 8.dp, bottom = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(ch.toString(), color = pal.acc, fontWeight = FontWeight.Black, fontSize = 14.sp, letterSpacing = 3.sp)
            if (count > 0) {
                Spacer(Modifier.width(8.dp))
                Text("$count", color = pal.sub, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun SectionTitle(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector? = null) {
    val pal = LocalPal.current
    Row(Modifier.padding(start = 24.dp, end = 20.dp, top = 14.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) { Icon(icon, null, tint = pal.acc, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)) }
        Text(text, color = pal.sub, fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 1.5.sp)
    }
}

@Composable
fun FavAvatar(c: Contact, onClick: () -> Unit) {
    val pal = LocalPal.current
    val inf = rememberInfiniteTransition(label = "fav")
    val rot by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "rot")
    Column(Modifier.width(78.dp).bounce(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(76.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.matchParentSize().graphicsLayer { rotationZ = rot }
                    .drawBehind { drawCircle(Brush.sweepGradient(listOf(pal.acc, pal.acc2, pal.acc)), style = Stroke(3.dp.toPx())) }
            )
            Avatar(c, 64.dp)
        }
        Spacer(Modifier.height(6.dp))
        Text(c.name.substringBefore(" "), color = pal.text, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun SwipeRow(onRight: () -> Unit, onLeft: () -> Unit, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val off = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var w by remember { mutableFloatStateOf(1f) }
    Box(modifier.onSizeChanged { w = it.width.toFloat() }) {
        val p = (off.value / (w * 0.26f)).coerceIn(-1f, 1f)
        if (abs(p) > 0.01f) {
            Box(
                Modifier.matchParentSize().padding(horizontal = 16.dp, vertical = 3.dp).clip(RoundedCornerShape(20.dp))
                    .background((if (p > 0) Color(0xFF22C55E) else Color(0xFF3B82F6)).copy(alpha = abs(p) * 0.92f)),
                contentAlignment = if (p > 0) Alignment.CenterStart else Alignment.CenterEnd
            ) {
                Icon(
                    if (p > 0) Icons.Rounded.Call else Icons.Rounded.Sms, null, tint = Color.White,
                    modifier = Modifier.padding(horizontal = 26.dp).size(26.dp).graphicsLayer { scaleX = 0.5f + 0.7f * abs(p); scaleY = 0.5f + 0.7f * abs(p) }
                )
            }
        }
        Box(
            Modifier.offset { IntOffset(off.value.roundToInt(), 0) }.pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        val v = off.value
                        scope.launch {
                            if (v > w * 0.26f) onRight() else if (v < -w * 0.26f) onLeft()
                            off.animateTo(0f, spring(0.6f, 320f))
                        }
                    },
                    onDragCancel = { scope.launch { off.animateTo(0f) } },
                    onHorizontalDrag = { ch, dx ->
                        ch.consume()
                        scope.launch { off.snapTo((off.value + dx * 0.85f).coerceIn(-w * 0.5f, w * 0.5f)) }
                    }
                )
            }
        ) { content() }
    }
}

@Composable
fun ContactRow(
    c: Contact, q: String, tags: List<String>, selected: Boolean, modifier: Modifier, fx: ScrollFx, last: Long?,
    compact: Boolean = false,
    onClick: (TransformOrigin) -> Unit, onLong: () -> Unit
) {
    val avatar = if (compact) 40.dp else 50.dp
    val rowPad = if (compact) 8.dp else 11.dp
    val pal = LocalPal.current
    val view = LocalView.current
    val coords = remember { arrayOfNulls<LayoutCoordinates>(1) } // plain holder: writing state here would recompose every row on every scroll frame
    var pressed by remember { mutableStateOf(false) }
    val sc by animateFloatAsState(if (pressed) 0.97f else 1f, spring(0.5f, 600f), label = "rowp")
    val shape = RoundedCornerShape(20.dp)
    val bgc = if (selected) pal.acc.copy(alpha = 0.2f) else if (pal.dark) pal.card else Color.White
    Row(
        modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 3.dp)
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .clip(shape).background(bgc)
            .border(1.dp, if (selected) pal.acc else pal.line, shape)
            .onGloballyPositioned { coords[0] = it }
            .pointerInput(c.id) {
                detectTapGestures(
                    onPress = { pressed = true; tryAwaitRelease(); pressed = false },
                    onLongPress = { onLong() },
                    onTap = { o ->
                        val lc = coords[0]
                        val r = lc?.localToRoot(o)
                        val to = if (r != null && view.width > 0) TransformOrigin((r.x / view.width).coerceIn(0f, 1f), (r.y / view.height).coerceIn(0f, 1f)) else TransformOrigin.Center
                        onClick(to)
                    }
                )
            }
            .padding(horizontal = 14.dp, vertical = rowPad),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(contentAlignment = Alignment.Center) {
            Avatar(c, avatar, Modifier.graphicsLayer { translationY = -fx.v * 0.45f })
            androidx.compose.animation.AnimatedVisibility(selected, enter = scaleIn(spring(0.5f, 500f)) + fadeIn(), exit = scaleOut() + fadeOut()) {
                Box(Modifier.size(avatar).clip(CircleShape).background(pal.acc.copy(alpha = 0.9f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(26.dp))
                }
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f).graphicsLayer { translationY = fx.v * 0.2f }) {
            Text(remember(c.name, q, pal.acc) { highlight(c.name.ifBlank { "(No name)" }, q, pal.acc) }, color = pal.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val sub = c.phones.firstOrNull()?.number ?: c.emails.firstOrNull()?.address ?: c.org
            if (sub.isNotBlank()) Text(highlight(sub, q, pal.acc), color = pal.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (tags.isNotEmpty()) Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                for (t in tags.take(3)) Text(
                    t, color = pal.acc, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(pal.acc.copy(alpha = 0.14f)).padding(horizontal = 7.dp, vertical = 2.dp)
                )
            }
        }
        Column(horizontalAlignment = Alignment.End) {
            if (c.starred) Icon(Icons.Rounded.Star, null, tint = Color(0xFFFFC53D), modifier = Modifier.size(20.dp))
            if (last != null) Text(ago(last), color = pal.sub, fontSize = 11.sp)
        }
    }
}

@Composable
fun FastScroller(letters: List<Char>, onJump: (Char) -> Unit, modifier: Modifier = Modifier) {
    val pal = LocalPal.current
    val buzz = rememberBuzz()
    var h by remember { mutableFloatStateOf(1f) }
    var dragY by remember { mutableFloatStateOf(-1f) }
    var cur by remember { mutableIntStateOf(-1) }
    val dragging = dragY >= 0f
    val bs by animateFloatAsState(if (dragging) 1f else 0f, spring(0.55f, 450f), label = "bub")
    fun idxAt(y: Float) = ((y / h) * letters.size).toInt().coerceIn(0, max(letters.size - 1, 0))
    if (letters.isEmpty()) return
    Box(
        modifier.width(34.dp).fillMaxHeight().onSizeChanged { h = it.height.toFloat() }
            .pointerInput(letters) {
                detectDragGestures(
                    onDragStart = { o -> dragY = o.y; val i = idxAt(o.y); cur = i; onJump(letters[i]) },
                    onDragEnd = { dragY = -1f; cur = -1 },
                    onDragCancel = { dragY = -1f; cur = -1 }
                ) { ch, _ ->
                    ch.consume()
                    dragY = ch.position.y
                    val i = idxAt(ch.position.y)
                    if (i != cur) { cur = i; buzz(HapticFeedbackType.TextHandleMove); onJump(letters[i]) }
                }
            }
            .pointerInput(letters) { detectTapGestures { o -> onJump(letters[idxAt(o.y)]) } }
    ) {
        Column(Modifier.fillMaxHeight().padding(vertical = 4.dp), verticalArrangement = Arrangement.SpaceEvenly, horizontalAlignment = Alignment.CenterHorizontally) {
            letters.forEachIndexed { i, ch ->
                val d = if (cur < 0) 9 else abs(i - cur)
                val near = if (cur < 0) 0f else max(0f, 1f - d / 3f)
                val s by animateFloatAsState(1f + near * 0.9f, spring(0.7f, 500f), label = "ls")
                val dx by animateFloatAsState(-near * 22f, spring(0.7f, 500f), label = "ldx")
                Text(
                    ch.toString(), fontSize = 10.sp, fontWeight = FontWeight.Bold,
                    color = if (cur >= 0 && d == 0) pal.acc else pal.sub,
                    modifier = Modifier.graphicsLayer { scaleX = s; scaleY = s; translationX = dx }
                )
            }
        }
        if (bs > 0.01f && cur in letters.indices) {
            Box(
                Modifier.offset { IntOffset((-112.dp.toPx()).roundToInt(), (dragY - 39.dp.toPx()).roundToInt()) }
                    .size(78.dp).graphicsLayer { scaleX = bs; scaleY = bs; alpha = bs.coerceIn(0f, 1f) }
                    .clip(CircleShape).background(Brush.linearGradient(listOf(pal.acc, pal.acc2))),
                contentAlignment = Alignment.Center
            ) { Text(letters[cur].toString(), color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Black) }
        }
    }
}

@Composable
fun HomeScreen(
    vm: ContactsVm, pick: Boolean,
    onOpen: (Contact, TransformOrigin) -> Unit, onNew: () -> Unit, onCleanup: () -> Unit,
    onInsights: () -> Unit, onSettings: () -> Unit, onPick: (Contact) -> Unit
) {
    val pal = LocalPal.current
    val motion = LocalMotion.current
    var showDialer by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val dens = LocalDensity.current
    val scope = rememberCoroutineScope()
    val buzz = rememberBuzz()
    val listState = rememberLazyListState()
    val fx = remember { ScrollFx() }
    LaunchedEffect(listState) {
        var lastI = 0
        var lastO = 0
        var smooth = 0f
        snapshotFlow { listState.isScrollInProgress }.collectLatest { moving ->
            while (true) {
                val done = withFrameNanos {
                    val i = listState.firstVisibleItemIndex
                    val o = listState.firstVisibleItemScrollOffset
                    val sz = listState.layoutInfo.visibleItemsInfo.firstOrNull()?.size ?: 0
                    val d = ((i - lastI) * sz + (o - lastO)).toFloat()
                    lastI = i; lastO = o
                    smooth += (d - smooth) * 0.28f
                    if (!moving && abs(smooth) < 0.4f) smooth = 0f
                    fx.v = smooth.coerceIn(-70f, 70f)
                    !moving && smooth == 0f
                }
                if (done) break
            }
        }
    }
    var query by rememberSaveable { mutableStateOf("") }
    var tag by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf(setOf<Long>()) }
    var onlyFav by rememberSaveable { mutableStateOf(false) }

    val shown by remember {
        derivedStateOf {
            val base = vm.contacts.filter {
                matches(it, query) && (!onlyFav || it.starred) && (tag == null || vm.tagsOf(it).contains(tag))
            }
            if (vm.sortLast) base.sortedBy { it.sortKeyLast.lowercase() } else base
        }
    }
    val groups = remember(shown, vm.sortLast) {
        shown.groupBy { if (vm.sortLast) letterOf(it.name.trim().split(" ").lastOrNull() ?: "") else it.letter }
            .entries.sortedBy { if (it.key == '#') '{' else it.key }.map { it.key to it.value }
    }
    val extras = query.isBlank() && tag == null && !onlyFav && !pick
    val favs = remember(vm.contacts) { vm.contacts.filter { it.starred } }
    val bdays = remember(vm.contacts) {
        vm.contacts.mapNotNull { c -> daysToBirthday(c.birthday)?.let { d -> c to d } }.filter { it.second <= 30 }.sortedBy { it.second }.take(3)
    }
    val hl = remember(vm.contacts) { health(vm.contacts) }
    val showFav = extras && favs.isNotEmpty()
    val showBday = extras && bdays.isNotEmpty()
    val recon = remember(vm.contacts, vm.lastTalk, vm.callsOk) { vm.reconnect() }
    val showRecon = extras && recon.isNotEmpty()
    val showClean = extras && hl.second > 0
    val lead = 1 + (if (showFav) 1 else 0) + (if (showBday) 1 else 0) + (if (showRecon) 1 else 0) + (if (showClean) 1 else 0)
    val letterIndex = remember(groups, lead) {
        val m = LinkedHashMap<Char, Int>()
        var i = lead
        for ((ch, l) in groups) { m[ch] = i; i += 1 + l.size }
        m
    }
    val allTags = vm.allTags()
    val inset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    // responsive: on tablets / foldables the list stays a comfortable column instead of stretching
    val screenW = LocalConfiguration.current.screenWidthDp.dp
    val side = ((screenW - 720.dp) / 2).coerceAtLeast(0.dp)
    val headerH = inset + 152.dp + (if (!pick) 44.dp else 0.dp)
    val collapse = remember { derivedStateOf { if (listState.firstVisibleItemIndex > 1) 1f else ((if (listState.firstVisibleItemIndex == 1) 400 else listState.firstVisibleItemScrollOffset) / 260f).coerceIn(0f, 1f) } }
    val scrollY = remember { derivedStateOf { listState.firstVisibleItemIndex * 300f + listState.firstVisibleItemScrollOffset } }

    Box(Modifier.fillMaxSize()) {
        LiveBackground { scrollY.value }
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(start = side, end = side, top = headerH, bottom = 130.dp + bottomInset),
            modifier = Modifier.fillMaxSize()
        ) {
            item(key = "top") { Spacer(Modifier.height(2.dp)) }
            if (showFav) item(key = "fav") {
                Column(Modifier.animateItem()) {
                    SectionTitle("FAVORITES", Icons.Rounded.Star)
                    LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(favs, key = { it.id }) { c -> FavAvatar(c) { onOpen(c, TransformOrigin.Center) } }
                    }
                }
            }
            if (showBday) item(key = "bday") {
                Column(Modifier.animateItem()) {
                    SectionTitle("BIRTHDAYS SOON", Icons.Rounded.Cake)
                    Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        for ((c, d) in bdays) Glass(Modifier.weight(1f).bounce { onOpen(c, TransformOrigin.Center) }, 18.dp) {
                            Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Avatar(c, 40.dp)
                                Spacer(Modifier.height(6.dp))
                                Text(c.name.substringBefore(" "), color = pal.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                Text(if (d == 0) "Today! 🎉" else if (d == 1) "Tomorrow" else "in $d days", color = if (d == 0) pal.acc else pal.sub, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
            if (showRecon) item(key = "recon") {
                Column(Modifier.animateItem()) {
                    SectionTitle("STAY IN TOUCH", Icons.Rounded.Favorite)
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(recon, key = { it.first.id }) { (c, t) ->
                            Glass(Modifier.width(150.dp).bounce { onOpen(c, TransformOrigin.Center) }, 20.dp) {
                                Column(Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Avatar(c, 38.dp)
                                        Spacer(Modifier.weight(1f))
                                        Box(
                                            Modifier.size(34.dp).clip(CircleShape).background(Color(0xFF22C55E)).bounce { c.phones.firstOrNull()?.let { callNum(ctx, it.number) } },
                                            contentAlignment = Alignment.Center
                                        ) { Icon(Icons.Rounded.Call, null, tint = Color.White, modifier = Modifier.size(18.dp)) }
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Text(c.name.substringBefore(" "), color = pal.text, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
                                    Text(if (t == null) "No calls yet" else ago(t) + " ago", color = pal.sub, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
            if (showClean) item(key = "clean") {
                Glass(Modifier.animateItem().padding(horizontal = 16.dp, vertical = 10.dp).fillMaxWidth().bounce { onCleanup() }, 20.dp) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.CleaningServices, null, tint = pal.acc, modifier = Modifier.size(26.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Address book health ${hl.first}%", color = pal.text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("${hl.second} things to tidy up — tap to fix", color = pal.sub, fontSize = 12.sp)
                        }
                    }
                }
            }
            if (vm.loading) item(key = "loading") { Text("Loading your people…", color = pal.sub, modifier = Modifier.padding(28.dp)) }
            if (!vm.loading && shown.isEmpty()) item(key = "empty") {
                Column(Modifier.fillMaxWidth().padding(40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.Search, null, tint = pal.sub, modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(10.dp))
                    Text(if (query.isBlank()) "No contacts yet" else "No match for “$query”", color = pal.sub, fontSize = 16.sp)
                }
            }
            for ((ch, list) in groups) {
                stickyHeader(key = "h$ch") { LetterHeader(ch, list.size) }
                val base = (letterIndex[ch] ?: 0) + 1
                itemsIndexed(list, key = { _, c -> c.id }, contentType = { _, _ -> 0 }) { idx, c ->
                    val absIdx = base + idx
                    val sel = c.id in selected
                    SwipeRow(
                        onRight = { buzz(HapticFeedbackType.LongPress); c.phones.firstOrNull()?.let { callNum(ctx, it.number) } },
                        onLeft = { buzz(HapticFeedbackType.LongPress); c.phones.firstOrNull()?.let { smsNum(ctx, it.number) } },
                        modifier = Modifier.animateItem().graphicsLayer {
                            compositingStrategy = CompositingStrategy.ModulateAlpha
                            val info = listState.layoutInfo
                            val vis = info.visibleItemsInfo
                            val g = if (vis.isEmpty()) -1 else absIdx - vis[0].index
                            val it2 = if (g in vis.indices && vis[g].index == absIdx) vis[g] else vis.firstOrNull { x -> x.index == absIdx }
                            if (it2 != null) {
                                val vh = (info.viewportEndOffset - info.viewportStartOffset).toFloat().coerceAtLeast(1f)
                                val mid = it2.offset + it2.size / 2f
                                val d = ((mid - vh / 2f) / (vh / 2f)).coerceIn(-1.3f, 1.3f)
                                val edge = (abs(d) - 0.6f).coerceAtLeast(0f) / 0.7f
                                alpha = 1f - 0.5f * edge
                                scaleX = 1f - 0.08f * edge * motion.k
                                scaleY = scaleX
                                if (motion.animated) {
                                    rotationX = (if (d < 0) 1f else -1f) * 24f * edge * motion.k
                                    cameraDistance = 14f * dens.density
                                }
                            }
                        }
                    ) {
                        ContactRow(
                            c, query, vm.tagsOf(c), sel, Modifier, fx, vm.lastTalk[c.id], compact = vm.compact,
                            onClick = { o ->
                                if (selected.isNotEmpty()) selected = if (sel) selected - c.id else selected + c.id
                                else if (pick) onPick(c) else onOpen(c, o)
                            },
                            onLong = { buzz(HapticFeedbackType.LongPress); selected = if (sel) selected - c.id else selected + c.id }
                        )
                    }
                }
            }
        }

        // header
        Box(
            Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(pal.bg.copy(alpha = 0.97f), pal.bg.copy(alpha = 0.9f), pal.bg.copy(alpha = 0f))))
                .padding(top = inset)
        ) {
            Column(Modifier.padding(horizontal = 20.dp).padding(top = 6.dp, bottom = 14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (pick) "Choose contact" else "Contacts", color = pal.text, fontWeight = FontWeight.Black, fontSize = 34.sp,
                            modifier = Modifier.graphicsLayer {
                                val c = collapse.value
                                scaleX = 1f - 0.3f * c; scaleY = scaleX
                                transformOrigin = TransformOrigin(0f, 0.5f)
                            }
                        )
                        Text(
                            "${vm.contacts.size} people" + if (favs.isNotEmpty()) " · ${favs.size} favorites" else "", color = pal.sub, fontSize = 13.sp,
                            modifier = Modifier.height(20.dp).graphicsLayer { alpha = 1f - collapse.value }
                        )
                    }
                    if (!pick) {
                        IconBtn(Icons.Rounded.Dialpad) { showDialer = true }
                        Spacer(Modifier.width(6.dp))
                        IconBtn(Icons.Rounded.Insights) { onInsights() }
                        Spacer(Modifier.width(6.dp))
                        IconBtn(Icons.Rounded.Settings) { onSettings() }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier.graphicsLayer {
                        val c = collapse.value
                        translationY = -3f * c
                        scaleX = 1f - 0.035f * c
                        scaleY = 1f - 0.035f * c
                    }
                ) { SearchPill(query, { query = it }) }
                if (!pick) {
                    LazyRow(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            TagChip("All", tag == null && !onlyFav) { tag = null; onlyFav = false }
                        }
                        item {
                            TagChip("★ Favorites", onlyFav) { onlyFav = !onlyFav }
                        }
                        items(allTags) { t -> TagChip(t, tag == t) { tag = if (tag == t) null else t } }
                        if (tag != null) item {
                            val nums = shown.mapNotNull { it.phones.firstOrNull()?.number }
                            if (nums.isNotEmpty()) Row(
                                Modifier.clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(pal.acc, pal.acc2))).bounce { smsMany(ctx, nums) }
                                    .padding(horizontal = 14.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Rounded.Sms, null, tint = Color.White, modifier = Modifier.size(16.dp))
                                Text(" Message all ${nums.size}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // selection bar
        AnimatedVisibility(
            selected.isNotEmpty(), modifier = Modifier.align(Alignment.TopCenter),
            enter = slideInVertically { -it } + fadeIn(), exit = slideOutVertically { -it } + fadeOut()
        ) {
            val chosen = vm.contacts.filter { it.id in selected }
            Row(
                Modifier.fillMaxWidth().padding(top = inset + 8.dp, start = 12.dp, end = 12.dp).clip(RoundedCornerShape(26.dp))
                    .background(Brush.linearGradient(listOf(pal.acc, pal.acc2))).padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Close, null, tint = Color.White, modifier = Modifier.padding(8.dp).size(26.dp).bounce { selected = emptySet() })
                Text("${selected.size} selected", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                Icon(Icons.Rounded.Star, null, tint = Color.White, modifier = Modifier.padding(8.dp).size(26.dp).bounce { vm.star(chosen, true); selected = emptySet() })
                Icon(Icons.Rounded.StarBorder, null, tint = Color.White, modifier = Modifier.padding(8.dp).size(26.dp).bounce { vm.star(chosen, false); selected = emptySet() })
                Icon(Icons.Rounded.Delete, null, tint = Color.White, modifier = Modifier.padding(8.dp).size(26.dp).bounce { vm.delete(chosen); selected = emptySet() })
            }
        }

        // animated scroll rail on the very edge - drag it to fly through the list
        if (vm.rail && shown.isNotEmpty()) ScrollRail(
            state = listState,
            modifier = Modifier.align(Alignment.CenterEnd).padding(top = headerH - 20.dp, bottom = 96.dp + bottomInset)
        )

        // letter fast scroller
        if (shown.size > 12 && letterIndex.isNotEmpty()) FastScroller(
            letters = letterIndex.keys.toList(), onJump = { ch -> scope.launch { listState.scrollToItem(letterIndex[ch] ?: 0) } },
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 18.dp, top = headerH, bottom = 110.dp + bottomInset)
        )

        // back to top with a progress ring
        val listProg = remember {
            derivedStateOf {
                val li = listState.layoutInfo
                val total = li.totalItemsCount
                val first = li.visibleItemsInfo.firstOrNull()
                if (total <= 1 || first == null) 0f
                else {
                    val f = if (first.size > 0) first.offset.toFloat() / first.size else 0f
                    ((first.index + f) / (total - 1)).coerceIn(0f, 1f)
                }
            }
        }
        ScrollTopButton(
            visible = collapse.value > 0.25f,
            progress = { listProg.value },
            onClick = { scope.launch { listState.animateScrollToItem(0) } },
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 26.dp, bottom = 96.dp + bottomInset)
        )

        // FAB
        if (!pick) {
            val expanded = !listState.isScrollInProgress
            Row(
                Modifier.align(Alignment.BottomEnd).padding(end = 44.dp, bottom = 22.dp + bottomInset).enter(4)
                    .clip(RoundedCornerShape(30.dp)).background(Brush.linearGradient(listOf(pal.acc, pal.acc2)))
                    .bounce { onNew() }.padding(horizontal = 18.dp, vertical = 16.dp).animateContentSize(spring(0.8f, 400f)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Add, null, tint = Color.White, modifier = Modifier.size(26.dp))
                if (expanded) { Spacer(Modifier.width(8.dp)); Text("New contact", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1) }
            }
        }

        DialerOverlay(
            show = showDialer, vm = vm,
            onClose = { showDialer = false },
            onOpen = { c -> showDialer = false; onOpen(c, TransformOrigin.Center) }
        )
    }
}

@Composable
fun TagChip(text: String, on: Boolean, onClick: () -> Unit) {
    val pal = LocalPal.current
    val a by animateFloatAsState(if (on) 1f else 0f, tween(250), label = "tc")
    Text(
        text, color = lerp(pal.sub, Color.White, a), fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(16.dp))
            .background(lerp(pal.card, pal.acc, a)).bounce { onClick() }.padding(horizontal = 14.dp, vertical = 7.dp)
    )
}
