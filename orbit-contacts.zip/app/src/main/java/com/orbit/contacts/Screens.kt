package com.orbit.contacts

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

@Composable
fun TopTitle(title: String, onBack: () -> Unit) {
    val pal = LocalPal.current
    val inset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    Row(Modifier.fillMaxWidth().padding(top = inset + 8.dp, start = 12.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        IconBtn(Icons.AutoMirrored.Rounded.ArrowBack) { onBack() }
        Text(title, color = pal.text, fontWeight = FontWeight.Black, fontSize = 24.sp, modifier = Modifier.padding(start = 14.dp))
    }
}

@Composable
fun CleanupScreen(vm: ContactsVm, onBack: () -> Unit, onOpen: (Contact) -> Unit) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val dups = remember(vm.contacts) { duplicates(vm.contacts) }
    val empty = remember(vm.contacts) { vm.contacts.filter { it.phones.isEmpty() && it.emails.isEmpty() } }
    val hl = remember(vm.contacts) { health(vm.contacts) }
    val score by animateIntAsState(hl.first, tween(1300, easing = FastOutSlowInEasing), label = "score")
    val sweep by animateFloatAsState(hl.first / 100f, tween(1300, easing = FastOutSlowInEasing), label = "sweep")
    val inset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    Box(Modifier.fillMaxSize()) {
        LiveBackground()
        LazyColumn(contentPadding = PaddingValues(top = inset + 72.dp, bottom = 40.dp + navInset)) {
            item {
                Box(Modifier.fillMaxWidth().padding(vertical = 16.dp).enter(0), contentAlignment = Alignment.Center) {
                    Box(
                        Modifier.size(170.dp).drawBehind {
                            val sw = 14.dp.toPx()
                            drawArc(pal.line, 0f, 360f, false, Offset(sw, sw), Size(size.width - 2 * sw, size.height - 2 * sw), style = Stroke(sw))
                            drawArc(Brush.sweepGradient(listOf(pal.acc, pal.acc2, pal.acc)), -90f, 360f * sweep, false, Offset(sw, sw), Size(size.width - 2 * sw, size.height - 2 * sw), style = Stroke(sw, cap = StrokeCap.Round))
                        }, contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$score", color = pal.text, fontSize = 52.sp, fontWeight = FontWeight.Black)
                            Text("health", color = pal.sub, fontSize = 13.sp)
                        }
                    }
                }
            }
            if (hl.second == 0) item {
                Text("Everything is tidy ✨", color = pal.text, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(24.dp))
            }
            if (dups.isNotEmpty()) item { SectionTitle("POSSIBLE DUPLICATES", Icons.Rounded.MergeType) }
            items(dups, key = { it.first.id * 1_000_003L + it.second.id }) { (a, b) ->
                Glass(Modifier.animateItem().padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth(), 20.dp) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.width(76.dp)) { Avatar(a, 44.dp); Avatar(b, 44.dp, Modifier.padding(start = 30.dp)) }
                        Column(Modifier.weight(1f)) {
                            Text("${a.name.ifBlank { "?" }} + ${b.name.ifBlank { "?" }}", color = pal.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1)
                            Text(a.phones.firstOrNull()?.number ?: b.phones.firstOrNull()?.number ?: "", color = pal.sub, fontSize = 12.sp)
                        }
                        Text(
                            "Merge", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                            modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(pal.acc, pal.acc2)))
                                .bounce { vm.merge(a, b); toast(ctx, "Merged") }.padding(horizontal = 16.dp, vertical = 9.dp)
                        )
                    }
                }
            }
            if (empty.isNotEmpty()) item { SectionTitle("NO NUMBER OR EMAIL", Icons.Rounded.Warning) }
            items(empty, key = { "e" + it.id }) { c ->
                Glass(Modifier.animateItem().padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth().bounce { onOpen(c) }, 20.dp) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(c, 40.dp)
                        Spacer(Modifier.width(12.dp))
                        Text(c.name.ifBlank { "(No name)" }, color = pal.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    }
                }
            }
        }
        TopTitle("Cleanup", onBack)
    }
}

@Composable
fun Toggle(on: Boolean, onChange: (Boolean) -> Unit) {
    val pal = LocalPal.current
    val x by animateFloatAsState(if (on) 1f else 0f, spring(0.6f, 500f), label = "tg")
    Box(
        Modifier.size(54.dp, 32.dp).clip(RoundedCornerShape(16.dp)).background(lerp(pal.line, pal.acc, x)).bounce { onChange(!on) }.padding(3.dp)
    ) {
        Box(Modifier.offset { IntOffset((x * 22.dp.toPx()).roundToInt(), 0) }.size(26.dp).clip(CircleShape).background(Color.White))
    }
}

@Composable
fun SettingRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String, i: Int, trailing: @Composable () -> Unit) {
    val pal = LocalPal.current
    Glass(Modifier.enter(i).padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth(), 20.dp) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = pal.acc, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = pal.text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                if (sub.isNotBlank()) Text(sub, color = pal.sub, fontSize = 12.sp)
            }
            trailing()
        }
    }
}

@Composable
fun SettingsScreen(vm: ContactsVm, onBack: () -> Unit) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val inset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/x-vcard")) { uri ->
        if (uri != null) vm.export(uri) { ok -> toast(ctx, if (ok) "Exported ${vm.contacts.size} contacts" else "Export failed") }
    }
    Box(Modifier.fillMaxSize()) {
        LiveBackground()
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = inset + 72.dp, bottom = 40.dp + navInset)) {
            SectionTitle("APPEARANCE", Icons.Rounded.Palette)
            Glass(Modifier.enter(0).padding(horizontal = 16.dp).fillMaxWidth(), 22.dp) {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(pal.line)) {
                        listOf("System", "Light", "Dark").forEachIndexed { i, t ->
                            val on = vm.themeMode == i
                            val a by animateFloatAsState(if (on) 1f else 0f, tween(300), label = "seg")
                            Box(
                                Modifier.weight(1f).padding(3.dp).clip(RoundedCornerShape(13.dp))
                                    .background(Brush.linearGradient(listOf(lerp(Color.Transparent, pal.acc, a), lerp(Color.Transparent, pal.acc2, a))))
                                    .bounce { vm.applyMode(i) }.padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) { Text(t, color = lerp(pal.sub, Color.White, a), fontWeight = FontWeight.Bold, fontSize = 14.sp) }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        if (pal.dark) "Aurora Night — glass, glow and living aurora light" else "Paper Studio — warm paper, soft shadows and pastel light",
                        color = pal.sub, fontSize = 12.sp
                    )
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Accents.forEachIndexed { i, (a1, a2) ->
                            val on = vm.accent == i
                            val s by animateFloatAsState(if (on) 1.18f else 1f, spring(0.45f, 500f), label = "sw")
                            Box(
                                Modifier.size(40.dp).graphicsLayer { scaleX = s; scaleY = s }.clip(CircleShape).background(Brush.linearGradient(listOf(a1, a2))).bounce { vm.applyAccent(i) },
                                contentAlignment = Alignment.Center
                            ) { if (on) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(22.dp)) }
                        }
                    }
                }
            }
            SectionTitle("LIST", Icons.Rounded.Sort)
            SettingRow(Icons.Rounded.Sort, "Sort by last name", "Off sorts by first name", 1) { Toggle(vm.sortLast) { vm.applySortLast(it) } }
            SettingRow(Icons.Rounded.AutoAwesome, "Cinematic intro", "Play the opening animation at launch", 2) { Toggle(vm.fancy) { vm.applyFancy(it) } }
            SectionTitle("BACKUP", Icons.Rounded.Share)
            SettingRow(Icons.Rounded.Share, "Export all contacts", "Save every contact as a .vcf file", 3) {
                Text("Export", color = pal.acc, fontWeight = FontWeight.Bold, modifier = Modifier.bounce { export.launch("orbit-contacts.vcf") }.padding(8.dp))
            }
            Text("Orbit Contacts 1.0 · ${vm.contacts.size} contacts", color = pal.sub, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(28.dp))
        }
        TopTitle("Settings", onBack)
    }
}
