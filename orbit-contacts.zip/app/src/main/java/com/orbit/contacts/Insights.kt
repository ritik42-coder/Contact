package com.orbit.contacts

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.max

/** Small metric tile used on the insights screen. */
@Composable
private fun StatTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    value: Int,
    label: String,
    tint: Color,
    i: Int,
    modifier: Modifier = Modifier
) {
    val pal = LocalPal.current
    Glass(modifier.enter(i), 20.dp) {
        Column(Modifier.padding(14.dp)) {
            Box(
                Modifier.size(34.dp).clip(CircleShape).background(tint.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) { Icon(icon, null, tint = tint, modifier = Modifier.size(19.dp)) }
            Spacer(Modifier.height(10.dp))
            AnimatedInt(value, pal.text, 26.sp)
            Text(label, color = pal.sub, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun Bar(label: String, value: Int, maxValue: Int, i: Int, modifier: Modifier = Modifier) {
    val pal = LocalPal.current
    val g = remember { Animatable(0f) }
    LaunchedEffect(value, maxValue) {
        delay(60L * i)
        g.animateTo(1f, spring(dampingRatio = 0.7f, stiffness = 220f))
    }
    val target = if (maxValue <= 0) 0.06f else (value.toFloat() / maxValue).coerceIn(0.06f, 1f)
    Column(modifier.width(30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.width(22.dp).height(96.dp * target * g.value + 4.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Brush.verticalGradient(listOf(pal.acc2, pal.acc))),
            contentAlignment = Alignment.BottomCenter
        ) {}
        Spacer(Modifier.height(6.dp))
        Text(label, color = pal.sub, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text("$value", color = pal.text, fontSize = 10.sp)
    }
}

@Composable
fun InsightsScreen(vm: ContactsVm, onBack: () -> Unit, onOpen: (Contact) -> Unit, onCleanup: () -> Unit) {
    val pal = LocalPal.current
    val inset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val st = rememberLazyListState()

    val cs = vm.contacts
    val hl = remember(cs) { health(cs) }
    val dups = remember(cs) { duplicates(cs).size }
    val withPhoto = remember(cs) { cs.count { it.photo != null } }
    val noPhone = remember(cs) { cs.count { it.phones.isEmpty() } }
    val favs = remember(cs) { cs.count { it.starred } }
    val tagsN = vm.allTags().size
    val byLetter = remember(cs) {
        cs.groupBy { it.letter }.map { it.key to it.value.size }.sortedByDescending { it.second }.take(9)
    }
    val maxLetter = byLetter.maxOfOrNull { it.second } ?: 0
    val recent = remember(cs, vm.lastTalk) {
        vm.lastTalk.entries.sortedByDescending { it.value }.take(5)
            .mapNotNull { e -> cs.firstOrNull { it.id == e.key }?.let { it to e.value } }
    }
    val bdays = remember(cs) {
        cs.mapNotNull { c -> daysToBirthday(c.birthday)?.let { c to it } }.sortedBy { it.second }.take(5)
    }
    val score by animateIntAsState(hl.first, tween(1400, easing = FastOutSlowInEasing), label = "sc")
    val sweep = remember { Animatable(0f) }
    LaunchedEffect(hl.first) { sweep.animateTo(hl.first / 100f, tween(1400, easing = FastOutSlowInEasing)) }

    Box(Modifier.fillMaxSize()) {
        LiveBackground()
        LazyColumn(
            state = st,
            contentPadding = PaddingValues(top = inset + 74.dp, bottom = 48.dp + navInset)
        ) {
            item(key = "hero") {
                Glass(Modifier.padding(horizontal = 16.dp).fillMaxWidth().enter(0), 26.dp) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(120.dp).drawBehind {
                                val sw = 11.dp.toPx()
                                val tl = Offset(sw / 2f, sw / 2f)
                                val sz = Size(size.width - sw, size.height - sw)
                                drawArc(pal.line, 0f, 360f, false, tl, sz, style = Stroke(sw))
                                drawArc(
                                    Brush.sweepGradient(listOf(pal.acc, pal.acc2, pal.acc)),
                                    -90f, 360f * sweep.value, false, tl, sz,
                                    style = Stroke(sw, cap = StrokeCap.Round)
                                )
                            },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                AnimatedInt(score, pal.text, 34.sp)
                                Text("health", color = pal.sub, fontSize = 11.sp)
                            }
                        }
                        Spacer(Modifier.width(18.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Your address book", color = pal.text, fontWeight = FontWeight.Black, fontSize = 19.sp)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                if (hl.second == 0) "Everything is tidy. Nothing to fix."
                                else "${hl.second} things worth fixing - duplicates and empty cards.",
                                color = pal.sub, fontSize = 12.sp
                            )
                            Spacer(Modifier.height(10.dp))
                            Row(
                                Modifier.clip(RoundedCornerShape(14.dp))
                                    .background(Brush.linearGradient(listOf(pal.acc, pal.acc2)))
                                    .bounce { onCleanup() }.padding(horizontal = 14.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Rounded.CleaningServices, null, tint = Color.White, modifier = Modifier.size(15.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Tidy up", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            item(key = "statsTitle") { SectionTitle("AT A GLANCE", Icons.Rounded.Insights) }
            item(key = "stats1") {
                Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(Icons.Rounded.People, cs.size, "Contacts", pal.acc, 1, Modifier.weight(1f))
                    StatTile(Icons.Rounded.Star, favs, "Favorites", Color(0xFFFFC53D), 2, Modifier.weight(1f))
                }
            }
            item(key = "stats2") {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(Icons.Rounded.PhotoCamera, withPhoto, "With photo", Color(0xFF22C55E), 3, Modifier.weight(1f))
                    StatTile(Icons.Rounded.PhoneDisabled, noPhone, "No number", Color(0xFFF97316), 4, Modifier.weight(1f))
                }
            }
            item(key = "stats3") {
                Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(Icons.Rounded.MergeType, dups, "Duplicates", Color(0xFFEF4444), 5, Modifier.weight(1f))
                    StatTile(Icons.Rounded.Tag, tagsN, "Tags", Color(0xFF8B5CF6), 6, Modifier.weight(1f))
                }
            }

            if (byLetter.isNotEmpty()) {
                item(key = "chartTitle") { SectionTitle("PEOPLE BY LETTER", Icons.Rounded.BarChart) }
                item(key = "chart") {
                    Glass(Modifier.padding(horizontal = 16.dp).fillMaxWidth().enter(2), 22.dp) {
                        Row(
                            Modifier.padding(horizontal = 12.dp, vertical = 16.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            byLetter.forEachIndexed { i, (ch, n) ->
                                Bar(ch.toString(), n, maxLetter, i)
                            }
                        }
                    }
                }
            }

            if (recent.isNotEmpty()) {
                item(key = "recentTitle") { SectionTitle("RECENTLY IN TOUCH", Icons.Rounded.AccessTime) }
                items(recent, key = { "r" + it.first.id }) { (c, t) ->
                    Glass(
                        Modifier.padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth()
                            .bounce { onOpen(c) }, 18.dp
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar(c, 38.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(c.name.ifBlank { "(No name)" }, color = pal.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("last talked ${ago(t)} ago", color = pal.sub, fontSize = 12.sp)
                            }
                            Icon(Icons.Rounded.ChevronRight, null, tint = pal.sub, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }

            if (bdays.isNotEmpty()) {
                item(key = "bdTitle") { SectionTitle("BIRTHDAYS COMING UP", Icons.Rounded.Cake) }
                items(bdays, key = { "b" + it.first.id }) { (c, d) ->
                    Glass(
                        Modifier.padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth()
                            .bounce { onOpen(c) }, 18.dp
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar(c, 38.dp)
                            Spacer(Modifier.width(12.dp))
                            Text(c.name.ifBlank { "(No name)" }, color = pal.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                if (d == 0) "Today!" else if (d == 1) "Tomorrow" else "in $d days",
                                color = if (d <= 1) pal.acc else pal.sub, fontSize = 12.sp, fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            val allTags = vm.allTags()
            if (allTags.isNotEmpty()) {
                item(key = "tagTitle") { SectionTitle("YOUR TAGS", Icons.Rounded.Tag) }
                item(key = "tags") {
                    FlowRowCompat(allTags.take(14), vm)
                }
            }

            item(key = "foot") {
                Text(
                    "All of this is computed on your phone. Nothing leaves the device.",
                    color = pal.sub, fontSize = 11.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(24.dp)
                )
            }
        }
        if (vm.rail) ScrollRail(
            state = st,
            modifier = Modifier.align(Alignment.CenterEnd).padding(top = inset + 64.dp, bottom = navInset + 40.dp)
        )
        TopTitle("Insights", onBack)
    }
}

/** Simple wrapping tag cloud built from rows, so it works on every Compose version. */
@Composable
private fun FlowRowCompat(tags: List<String>, vm: ContactsVm) {
    val pal = LocalPal.current
    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        for (chunk in tags.chunked(3)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (t in chunk) {
                    val n = vm.contacts.count { vm.tagsOf(it).contains(t) }
                    Row(
                        Modifier.clip(RoundedCornerShape(14.dp)).background(pal.acc.copy(alpha = 0.14f))
                            .padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(t, color = pal.acc, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(6.dp))
                        Text("$n", color = pal.sub, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
