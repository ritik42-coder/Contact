package com.orbit.contacts

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

private val EaseOutQuint = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)

/** Progress of [t] inside [a]..[b], shaped with a soft "quint" ease-out. */
fun easeOut(a: Float, b: Float, t: Float): Float = EaseOutQuint.transform(((t - a) / (b - a)).coerceIn(0f, 1f))

/** Circular reveal that grows from the middle of the screen (where the logo is). */
class RevealShape(private val f: Float) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val r = f * hypot(size.width, size.height) / 2f
        return Outline.Generic(Path().apply { addOval(Rect(Offset(size.width / 2f, size.height / 2f), r)) })
    }
}

private class Sat(val orbit: Float, val speed: Float, val phase: Float, val mix: Float, val size: Float, val flat: Float)

/**
 * 3.6 s opening: ambient light fades in, a gradient ring draws itself, seven contacts orbit it with
 * comet trails, they spiral into the centre and ignite a glass core that becomes the contact mark,
 * a soft bloom rolls out, the wordmark settles in, and the app is revealed through a circular wipe.
 * Everything is cached brushes + a few hundred cheap draw calls, so it stays at full frame rate.
 */
@Composable
fun IntroCanvas(p: Animatable<Float, AnimationVector1D>, onSkip: () -> Unit) {
    val pal = LocalPal.current
    val acc = pal.acc
    val acc2 = pal.acc2
    val dark = pal.dark
    val ink = if (dark) Color.White else Color(0xFF1B1D2A)
    val sats = remember {
        listOf(
            Sat(1.00f, 1.0f, 0.0f, 0.0f, 1.0f, 0.5f), Sat(0.78f, -1.3f, 1.2f, 0.2f, 0.85f, 0.45f),
            Sat(1.22f, 0.8f, 2.4f, 0.4f, 1.1f, 0.6f), Sat(0.62f, 1.7f, 3.3f, 0.6f, 0.7f, 0.4f),
            Sat(1.40f, -0.7f, 4.1f, 0.8f, 0.95f, 0.55f), Sat(0.90f, 1.1f, 5.0f, 1.0f, 0.8f, 0.5f),
            Sat(1.10f, -1.5f, 5.8f, 0.3f, 0.75f, 0.35f)
        )
    }
    val dust = remember { val r = Random(3); List(34) { floatArrayOf(r.nextFloat(), r.nextFloat(), 0.3f + r.nextFloat(), r.nextFloat()) } }
    Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { onSkip() } }) {
        Box(
            Modifier.fillMaxSize().drawWithCache {
                val w = size.width
                val h = size.height
                val m = min(w, h)
                val u = m / 400f
                val c0 = Offset(w / 2f, h / 2f)
                val maxR = hypot(w, h) / 2f
                val bg = Brush.radialGradient(
                    if (dark) listOf(Color(0xFF15102E), Color(0xFF05060B)) else listOf(Color.White, Color(0xFFF0E6FF)), c0, maxR
                )
                val glowA = Brush.radialGradient(listOf(acc.copy(alpha = if (dark) 0.35f else 0.22f), Color.Transparent), Offset(w * 0.3f, h * 0.35f), m * 0.95f)
                val glowB = Brush.radialGradient(listOf(acc2.copy(alpha = if (dark) 0.28f else 0.2f), Color.Transparent), Offset(w * 0.72f, h * 0.68f), m * 0.95f)
                val ring = Brush.sweepGradient(listOf(acc, acc2, acc.copy(alpha = 0.08f), acc), c0)
                val disc = Brush.linearGradient(listOf(acc, acc2), Offset(c0.x - 60f * u, c0.y - 60f * u), Offset(c0.x + 60f * u, c0.y + 60f * u))
                onDrawBehind {
                    val t = p.value
                    drawRect(bg)
                    val a0 = easeOut(0f, 0.35f, t)
                    drawRect(glowA, alpha = a0)
                    drawRect(glowB, alpha = a0)
                    for (d in dust) {
                        val y = (d[1] - t * 0.08f * d[2] + 1f) % 1f
                        drawCircle(ink, (0.8f + d[2]) * u, Offset(d[0] * w, y * h), alpha = 0.18f * a0 * (0.5f + 0.5f * sin(t * 9f + d[3] * 6f)))
                    }
                    val ringR = m * 0.2f
                    val rt = easeOut(0.04f, 0.34f, t)
                    if (rt > 0f) {
                        drawCircle(ink, ringR, c0, alpha = 0.07f * rt, style = Stroke(1.5f * u))
                        rotate(t * 330f, c0) {
                            drawArc(ring, 0f, 360f * rt, false, Offset(c0.x - ringR, c0.y - ringR), Size(ringR * 2f, ringR * 2f), style = Stroke(2.6f * u, cap = StrokeCap.Round))
                        }
                    }
                    val conv = easeOut(0.55f, 0.74f, t)
                    for ((i, s) in sats.withIndex()) {
                        val ap = easeOut(0.16f + 0.03f * i, 0.36f + 0.03f * i, t)
                        if (ap <= 0f) continue
                        val rr = ringR * s.orbit * (1f - conv) * (0.6f + 0.4f * ap)
                        val ang = s.phase + t * 6.5f * s.speed * (1f + conv * 1.2f)
                        val col = lerp(acc, acc2, s.mix)
                        val dir = if (s.speed > 0f) 1f else -1f
                        for (k in 8 downTo 0) {
                            val a = ang - k * 0.085f * dir
                            val f = 1f - k / 9f
                            drawCircle(
                                col, (3.2f * s.size * f + 0.6f) * u,
                                Offset(c0.x + cos(a) * rr, c0.y + sin(a) * rr * (1f - s.flat * 0.45f)),
                                alpha = (0.1f + 0.9f * f * f) * ap * (1f - conv * 0.9f)
                            )
                        }
                    }
                    val core = easeOut(0.60f, 0.82f, t)
                    if (core > 0f) {
                        val r = m * 0.095f * core * (1f + 0.035f * sin(t * 40f))
                        drawCircle(acc, r * 2.4f, c0, alpha = 0.10f * core)
                        drawCircle(acc2, r * 1.7f, c0, alpha = 0.16f * core)
                        drawCircle(disc, r, c0)
                        val g = easeOut(0.72f, 0.88f, t)
                        if (g > 0f) {
                            drawCircle(Color.White, r * 0.26f * g, Offset(c0.x, c0.y - r * 0.22f), alpha = g)
                            drawArc(Color.White, 200f, 140f * g, false, Offset(c0.x - r * 0.5f, c0.y + r * 0.02f), Size(r, r), alpha = g, style = Stroke(r * 0.13f, cap = StrokeCap.Round))
                        }
                        val bl = (t - 0.66f) / 0.22f
                        if (bl in 0f..1f) drawCircle(acc2, m * (0.10f + 0.5f * easeOut(0f, 1f, bl)), c0, alpha = (1f - bl) * 0.45f, style = Stroke(2.5f * u))
                    }
                }
            }
        )
        Column(Modifier.align(Alignment.Center).padding(top = 250.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row {
                "ORBIT".forEachIndexed { i, ch ->
                    Text(
                        ch.toString(), color = ink, fontSize = 38.sp, fontWeight = FontWeight.Light, letterSpacing = 8.sp,
                        modifier = Modifier.graphicsLayer {
                            val a = easeOut(0.78f + 0.022f * i, 0.92f + 0.022f * i, p.value)
                            alpha = a
                            translationY = (1f - a) * 34f
                        }
                    )
                }
            }
            Text(
                "your people, in motion", color = ink.copy(alpha = 0.6f), fontSize = 12.sp, letterSpacing = 4.sp,
                modifier = Modifier.graphicsLayer { alpha = easeOut(0.88f, 0.98f, p.value) }
            )
        }
    }
}
