package com.orbit.contacts

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

private fun bump(t: Float, c: Float, w: Float): Float { val x = (t - c) / w; return exp(-x * x) }

/**
 * Cinematic opening (about 4.5 s): letterbox bars slide in, warp-speed star streaks, a swarm of contact
 * orbs spirals in, the core ignites with a flash, camera shake and shockwave, the contact glyph draws
 * itself, the title assembles letter by letter, then the whole scene dissolves into the app.
 */
@Composable
fun IntroCanvas(p: Animatable<Float, AnimationVector1D>, onSkip: () -> Unit) {
    val pal = LocalPal.current
    val stars = remember { val r = Random(11); List(260) { floatArrayOf(r.nextFloat() * 6.2832f, r.nextFloat(), 0.4f + r.nextFloat() * 1.4f, r.nextFloat()) } }
    val orbs = remember { val r = Random(5); List(44) { floatArrayOf(r.nextFloat() * 6.2832f, 0.55f + r.nextFloat() * 0.75f, r.nextFloat(), 0.7f + r.nextFloat() * 0.6f) } }
    val acc = pal.acc
    val acc2 = pal.acc2
    val dark = pal.dark
    Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { onSkip() } }) {
        Canvas(Modifier.fillMaxSize()) {
            val t = p.value
            val w = size.width
            val h = size.height
            val m = min(w, h)
            val u = m / 400f
            val cx = w / 2f
            val cy = h / 2f
            val maxR = hypot(w, h) / 2f
            val c0 = Offset(cx, cy)
            drawRect(
                if (dark) Brush.radialGradient(listOf(Color(0xFF16112F), Color(0xFF05060B)), c0, maxR)
                else Brush.radialGradient(listOf(Color(0xFFFFFFFF), Color(0xFFF1E6FF)), c0, maxR)
            )
            val flash = bump(t, 0.585f, 0.045f)
            val shake = flash * 16f * (1f - sm(0.585f, 0.76f, t))
            translate(sin(t * 190f) * shake, cos(t * 230f) * shake) {
                // 1. warp streaks
                val w1 = sm(0f, 0.3f, t)
                val fade = 1f - sm(0.2f, 0.34f, t)
                if (fade > 0f) {
                    val sc = if (dark) Color.White else acc
                    for (s in stars) {
                        val d1 = (s[1] + w1 * w1 * s[2] * 1.6f) * maxR
                        val d0 = max(d1 - (4f * u + w1 * 150f * u * s[2]), 0f)
                        val dx = cos(s[0]); val dy = sin(s[0])
                        drawLine(
                            sc, Offset(cx + dx * d0, cy + dy * d0), Offset(cx + dx * d1, cy + dy * d1),
                            strokeWidth = (1f + s[2]) * u, alpha = fade * (0.25f + 0.75f * s[3]) * sm(0f, 0.06f, t)
                        )
                    }
                }
                // 2. orb swarm spirals into a ring
                val o = sm(0.16f, 0.58f, t)
                val ringR = m * 0.22f
                for ((i, ob) in orbs.withIndex()) {
                    val rr = ringR + ob[1] * m * 0.9f * (1f - o) * (1f - o)
                    val a = ob[0] + t * (5f + ob[3] * 4f) * (1f - 0.65f * o)
                    val x = cx + cos(a) * rr
                    val y = cy + sin(a) * rr * (0.55f + 0.45f * o)
                    val col = lerp(acc, acc2, ob[2])
                    val r = (2.4f + 3.2f * ob[3]) * u
                    drawCircle(col, r * 3.2f, Offset(x, y), alpha = 0.22f * o)
                    drawCircle(col, r, Offset(x, y), alpha = 0.95f * o)
                    if (flash > 0.05f) {
                        drawCircle(Color(0xFFFF3B5C), r, Offset(x - 5f * flash * u, y), alpha = 0.5f * flash)
                        drawCircle(Color(0xFF00E5FF), r, Offset(x + 5f * flash * u, y), alpha = 0.5f * flash)
                    }
                    if (i == 0) { /* keep loop index used */ }
                }
                // 3. core ignition + flash
                val core = sm(0.40f, 0.58f, t)
                if (core > 0f) {
                    val rad = m * (0.05f + 0.25f * core + 0.9f * flash)
                    drawCircle(
                        Brush.radialGradient(listOf(Color.White.copy(alpha = 0.95f * core), acc.copy(alpha = 0.5f * core), Color.Transparent), c0, rad),
                        radius = rad, center = c0
                    )
                }
                // 4. shockwaves
                val sw = (t - 0.585f) / 0.32f
                if (sw in 0f..1f) {
                    drawCircle(acc2, sw * maxR * 1.15f, c0, alpha = (1f - sw) * 0.8f, style = Stroke(width = (7f * (1f - sw) + 1f) * u))
                    drawCircle(acc, sw * sw * maxR * 1.0f, c0, alpha = (1f - sw) * 0.6f, style = Stroke(width = (4f * (1f - sw) + 1f) * u))
                }
                // 5. contact glyph draws itself
                val g = sm(0.60f, 0.80f, t)
                if (g > 0f) {
                    val gr = m * 0.075f
                    val gc = if (dark) Color.White else Color(0xFF1B1D2A)
                    drawCircle(
                        Brush.radialGradient(listOf(acc.copy(alpha = 0.45f * g), Color.Transparent), c0, gr * 4.2f),
                        radius = gr * 4.2f, center = c0
                    )
                    val sw2 = 3.4f * u
                    drawArc(gc, -90f, 360f * sm(0.60f, 0.70f, t), false, Offset(cx - gr * 0.55f, cy - gr * 1.55f), Size(gr * 1.1f, gr * 1.1f), style = Stroke(sw2, cap = StrokeCap.Round))
                    drawArc(gc, 200f, 140f * sm(0.68f, 0.80f, t), false, Offset(cx - gr * 1.15f, cy - gr * 0.2f), Size(gr * 2.3f, gr * 2.3f), style = Stroke(sw2, cap = StrokeCap.Round))
                }
                // lens flare
                if (flash > 0.02f) {
                    drawRect(
                        Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.9f * flash), Color.Transparent)),
                        Offset(0f, cy - 2f * u), Size(w, 4f * u)
                    )
                }
            }
            // vignette + letterbox
            if (dark) drawRect(Brush.radialGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f)), c0, maxR))
            val bar = h * 0.115f * sm(0f, 0.1f, t) * (1f - sm(0.88f, 1f, t))
            val barC = if (dark) Color.Black else Color(0xFF1B1D2A)
            drawRect(barC, Offset(0f, 0f), Size(w, bar))
            drawRect(barC, Offset(0f, h - bar), Size(w, bar))
        }
        Column(Modifier.align(Alignment.Center).padding(top = 230.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            val tc = if (dark) Color.White else Color(0xFF1B1D2A)
            Row {
                "ORBIT".forEachIndexed { i, ch ->
                    Text(
                        ch.toString(), color = tc, fontSize = 42.sp, fontWeight = FontWeight.Black, letterSpacing = 6.sp,
                        modifier = Modifier.graphicsLayer {
                            val a = sm(0.72f + 0.025f * i, 0.80f + 0.025f * i, p.value)
                            alpha = a
                            translationY = (1f - a) * 46f
                            scaleX = 0.5f + 0.5f * a
                            scaleY = 0.5f + 0.5f * a
                        }
                    )
                }
            }
            Text(
                "your people, in motion", color = tc.copy(alpha = 0.7f), fontSize = 14.sp, letterSpacing = 3.sp,
                modifier = Modifier.graphicsLayer { alpha = sm(0.82f, 0.92f, p.value) }
            )
        }
    }
}
