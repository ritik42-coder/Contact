package com.orbit.contacts

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.widget.Toast
import androidx.core.content.ContextCompat

fun toast(ctx: Context, s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

private fun go(ctx: Context, i: Intent) { runCatching { ctx.startActivity(i) }.onFailure { toast(ctx, "No app can do that") } }

fun callNum(ctx: Context, n: String) {
    val ok = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
    go(ctx, Intent(if (ok) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(n))))
}

fun smsNum(ctx: Context, n: String) = go(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(n))))
fun mailTo(ctx: Context, a: String) = go(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$a")))
fun whatsapp(ctx: Context, n: String) = go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + digits(n))))
fun openUrl(ctx: Context, u: String) = go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(if (u.startsWith("http")) u else "https://$u")))
fun openMap(ctx: Context, a: String) = go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(a))))

fun copyText(ctx: Context, s: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("orbit", s))
    toast(ctx, "Copied")
}

fun shareVcard(ctx: Context, c: Contact) {
    val u = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_VCARD_URI, c.lookup)
    val i = Intent(Intent.ACTION_SEND).setType("text/x-vcard").putExtra(Intent.EXTRA_STREAM, u)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    go(ctx, Intent.createChooser(i, "Share contact"))
}

fun letterOf(s: String): Char {
    val c = s.trim().firstOrNull()?.uppercaseChar() ?: '#'
    return if (c.isLetter()) c else '#'
}

/** Decode an image from the gallery, centre-crop to a square and return it (max [px] wide). */
fun loadSquare(ctx: Context, uri: Uri, px: Int = 480): android.graphics.Bitmap? = try {
    val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, opts) }
    var s = 1
    while (opts.outWidth / (s * 2) >= px && opts.outHeight / (s * 2) >= px) s *= 2
    val o2 = android.graphics.BitmapFactory.Options().apply { inSampleSize = s }
    val b = ctx.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o2) }
    if (b == null) null else {
        val side = minOf(b.width, b.height)
        val sq = android.graphics.Bitmap.createBitmap(b, (b.width - side) / 2, (b.height - side) / 2, side, side)
        if (side > px) android.graphics.Bitmap.createScaledBitmap(sq, px, px, true) else sq
    }
} catch (e: Exception) { null }

fun jpegBytes(b: android.graphics.Bitmap): ByteArray {
    val o = java.io.ByteArrayOutputStream()
    b.compress(android.graphics.Bitmap.CompressFormat.JPEG, 86, o)
    return o.toByteArray()
}
