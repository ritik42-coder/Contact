package com.orbit.contacts

import android.app.DatePickerDialog
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Calendar
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun FloatField(
    value: String, onChange: (String) -> Unit, label: String, icon: ImageVector,
    modifier: Modifier = Modifier, kb: KeyboardType = KeyboardType.Text, singleLine: Boolean = true, valid: Boolean = false
) {
    val pal = LocalPal.current
    var focused by remember { mutableStateOf(false) }
    val up = focused || value.isNotEmpty()
    val lt by animateFloatAsState(if (up) 1f else 0f, spring(0.8f, 420f), label = "lbl")
    val glow by animateFloatAsState(if (focused) 1f else 0f, tween(320), label = "glow")
    val sh = RoundedCornerShape(18.dp)
    Row(
        modifier.fillMaxWidth().clip(sh).background(pal.card)
            .border(1.5.dp, Brush.linearGradient(listOf(pal.acc.copy(alpha = 0.14f + 0.86f * glow), pal.acc2.copy(alpha = 0.08f + 0.72f * glow))), sh)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = lerp(pal.sub, pal.acc, glow), modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(12.dp))
        Box(Modifier.weight(1f).heightIn(min = 54.dp), contentAlignment = Alignment.CenterStart) {
            Text(
                label, color = lerp(pal.sub, pal.acc, glow), fontSize = (16f - 4f * lt).sp,
                modifier = Modifier.graphicsLayer { translationY = -17.dp.toPx() * lt }
            )
            BasicTextField(
                value, onChange, singleLine = singleLine,
                textStyle = TextStyle(color = pal.text, fontSize = 17.sp), cursorBrush = SolidColor(pal.acc),
                keyboardOptions = KeyboardOptions(keyboardType = kb),
                modifier = Modifier.fillMaxWidth().padding(top = 14.dp).onFocusChanged { focused = it.isFocused }
            )
        }
        AnimatedVisibility(valid, enter = scaleIn(spring(0.35f, 500f)) + fadeIn(), exit = scaleOut() + fadeOut()) {
            Box(Modifier.size(26.dp).clip(CircleShape).background(Color(0xFF22C55E)), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun Appear(content: @Composable () -> Unit) {
    val st = remember { MutableTransitionState(false).apply { targetState = true } }
    AnimatedVisibility(st, enter = expandVertically(spring(0.8f, 380f)) + fadeIn() + slideInHorizontally { it / 4 }) { content() }
}

@Composable
fun TypeChip(text: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Text(
        text, color = pal.acc, fontSize = 12.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(pal.acc.copy(alpha = 0.14f)).bounce { onClick() }.padding(horizontal = 10.dp, vertical = 8.dp)
    )
}

private fun validMail(s: String) = s.contains("@") && s.substringAfter("@").contains(".")

@Composable
fun EditScreen(vm: ContactsVm, id: Long?, prefill: Draft?, onClose: () -> Unit) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val existing = id?.let { i -> vm.contacts.firstOrNull { it.id == i } }
    var d by remember { mutableStateOf(prefill ?: existing?.let { Draft.from(it) } ?: Draft()) }
    var photo by remember { mutableStateOf<ImageBitmap?>(null) }
    var more by remember { mutableStateOf(existing != null && (existing.org.isNotBlank() || existing.address.isNotBlank() || existing.note.isNotBlank() || existing.website.isNotBlank() || existing.birthday.isNotBlank())) }
    var phase by remember { mutableIntStateOf(0) }
    val shake = remember { Animatable(0f) }
    val conf = remember { Animatable(0f) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) loadSquare(ctx, uri)?.let { b -> photo = b.asImageBitmap(); d = d.copy(photo = jpegBytes(b)) }
    }
    val steps = listOf(
        d.name.isNotBlank(), d.phones.any { digits(it.number).length >= 5 }, d.emails.any { validMail(it.address) },
        d.org.isNotBlank() || d.title.isNotBlank(), d.birthday.isNotBlank() || d.address.isNotBlank(), photo != null || existing?.photo != null
    )
    val progress by animateFloatAsState(steps.count { it } / steps.size.toFloat(), spring(0.8f, 120f), label = "prog")
    val preview = Contact(0, "", d.name, false, existing?.photo, emptyList(), emptyList(), "", "", "", "", "", "", emptyList())
    val inset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val inf = rememberInfiniteTransition(label = "edit")
    val rot by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(8000, easing = LinearEasing)), label = "rot")

    LaunchedEffect(phase) { if (phase == 2) { conf.animateTo(1f, tween(950)); delay(150); onClose() } }

    fun save() {
        if (phase != 0) return
        if (d.name.isBlank() && d.phones.none { it.number.isNotBlank() }) {
            scope.launch { for (k in 0 until 4) { shake.animateTo(12f, tween(45)); shake.animateTo(-12f, tween(45)) }; shake.animateTo(0f, tween(45)) }
            toast(ctx, "Add a name or a number first")
            return
        }
        phase = 1
        vm.save(d, existing) { ok -> if (ok) phase = 2 else { phase = 0; toast(ctx, "Could not save — check permissions") } }
    }

    Box(Modifier.fillMaxSize()) {
        LiveBackground()
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).imePadding()
                .padding(top = inset + 64.dp, bottom = 120.dp + navInset).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // live preview
            Column(Modifier.fillMaxWidth().enter(0), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.size(150.dp).bounce { pick.launch("image/*") }.drawBehind {
                        val sw = 6.dp.toPx()
                        drawArc(pal.line, 0f, 360f, false, Offset(sw, sw), Size(size.width - 2 * sw, size.height - 2 * sw), style = Stroke(sw))
                        drawArc(Brush.sweepGradient(listOf(pal.acc, pal.acc2, pal.acc)), -90f, 360f * progress, false, Offset(sw, sw), Size(size.width - 2 * sw, size.height - 2 * sw), style = Stroke(sw, cap = StrokeCap.Round))
                    }, contentAlignment = Alignment.Center
                ) {
                    Avatar(preview, 116.dp, preview = photo)
                    Box(
                        Modifier.align(Alignment.BottomEnd).padding(10.dp).size(36.dp).clip(CircleShape).background(Brush.linearGradient(listOf(pal.acc, pal.acc2))),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Rounded.PhotoCamera, null, tint = Color.White, modifier = Modifier.size(19.dp)) }
                }
                Spacer(Modifier.height(8.dp))
                Text(d.name.ifBlank { "New contact" }, color = pal.text, fontSize = 24.sp, fontWeight = FontWeight.Black, modifier = Modifier.animateContentSize())
                Text("${(progress * 100).roundToInt()}% complete", color = pal.sub, fontSize = 13.sp)
            }
            FloatField(d.name, { d = d.copy(name = it) }, "Full name", Icons.Rounded.Person, Modifier.enter(1), valid = d.name.trim().length >= 2)
            d.phones.forEachIndexed { i, p ->
                key(i) {
                    Appear {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 0.dp)) {
                            FloatField(
                                p.number, { v -> d = d.copy(phones = d.phones.toMutableList().also { it[i] = p.copy(number = v) }) },
                                "Phone", Icons.Rounded.Phone, Modifier.weight(1f), KeyboardType.Phone, valid = digits(p.number).length >= 5
                            )
                            Spacer(Modifier.width(8.dp))
                            TypeChip(phoneLabel(p.type)) {
                                val nt = PHONE_TYPES[(PHONE_TYPES.indexOf(p.type) + 1) % PHONE_TYPES.size]
                                d = d.copy(phones = d.phones.toMutableList().also { it[i] = p.copy(type = nt) })
                            }
                            if (d.phones.size > 1) Icon(Icons.Rounded.Close, null, tint = pal.sub, modifier = Modifier.padding(start = 6.dp).size(26.dp).bounce { d = d.copy(phones = d.phones.toMutableList().also { it.removeAt(i) }) })
                        }
                    }
                }
            }
            AddRow("Add phone") { d = d.copy(phones = d.phones + PhoneNo("")) }
            d.emails.forEachIndexed { i, e ->
                key(i) {
                    Appear {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            FloatField(
                                e.address, { v -> d = d.copy(emails = d.emails.toMutableList().also { it[i] = e.copy(address = v) }) },
                                "Email", Icons.Rounded.Email, Modifier.weight(1f), KeyboardType.Email, valid = validMail(e.address)
                            )
                            Spacer(Modifier.width(8.dp))
                            TypeChip(mailLabel(e.type)) {
                                val nt = MAIL_TYPES[(MAIL_TYPES.indexOf(e.type) + 1) % MAIL_TYPES.size]
                                d = d.copy(emails = d.emails.toMutableList().also { it[i] = e.copy(type = nt) })
                            }
                            Icon(Icons.Rounded.Close, null, tint = pal.sub, modifier = Modifier.padding(start = 6.dp).size(26.dp).bounce { d = d.copy(emails = d.emails.toMutableList().also { it.removeAt(i) }) })
                        }
                    }
                }
            }
            AddRow("Add email") { d = d.copy(emails = d.emails + MailAd("")) }
            AddRow(if (more) "Fewer details" else "More details") { more = !more }
            AnimatedVisibility(more, enter = expandVertically(spring(0.85f, 300f)) + fadeIn(), exit = shrinkVertically() + fadeOut()) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    FloatField(d.org, { d = d.copy(org = it) }, "Company", Icons.Rounded.Business, Modifier.enter(0, "more"))
                    FloatField(d.title, { d = d.copy(title = it) }, "Job title", Icons.Rounded.Work, Modifier.enter(1, "more"))
                    Box(Modifier.enter(2, "more")) {
                        FloatField(d.birthday, {}, "Birthday", Icons.Rounded.Cake, valid = d.birthday.isNotBlank())
                        Box(Modifier.matchParentSize().clip(RoundedCornerShape(18.dp)).bounce {
                            val cal = Calendar.getInstance()
                            DatePickerDialog(ctx, { _, y, m, day -> d = d.copy(birthday = "%04d-%02d-%02d".format(y, m + 1, day)) }, cal.get(Calendar.YEAR) - 20, cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
                        })
                    }
                    FloatField(d.address, { d = d.copy(address = it) }, "Address", Icons.Rounded.LocationOn, Modifier.enter(3, "more"))
                    FloatField(d.website, { d = d.copy(website = it) }, "Website", Icons.Rounded.Language, Modifier.enter(4, "more"), KeyboardType.Uri)
                    FloatField(d.note, { d = d.copy(note = it) }, "Notes", Icons.Rounded.Notes, Modifier.enter(5, "more"), singleLine = false)
                }
            }
        }

        // top bar
        Row(Modifier.fillMaxWidth().padding(top = inset + 8.dp, start = 12.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(Icons.Rounded.Close) { onClose() }
            Text(if (existing == null) "New contact" else "Edit contact", color = pal.text, fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.padding(start = 14.dp))
        }

        // morphing save button
        val w by animateDpAsState(if (phase == 0) 170.dp else 60.dp, spring(0.7f, 380f), label = "w")
        Box(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 22.dp + navInset)
                .offset { IntOffset(shake.value.roundToInt(), 0) }.size(w, 60.dp)
                .drawBehind {
                    val t = conf.value
                    if (t > 0.01f && t < 0.99f) for (k in 0 until 18) {
                        val a = k * 0.349f
                        val r = t * 110.dp.toPx()
                        drawCircle(if (k % 2 == 0) pal.acc else pal.acc2, 5.dp.toPx() * (1f - t), center + Offset(cos(a) * r, sin(a) * r), alpha = 1f - t)
                    }
                }
                .clip(RoundedCornerShape(30.dp)).background(Brush.linearGradient(listOf(pal.acc, pal.acc2))).bounce { save() },
            contentAlignment = Alignment.Center
        ) {
            AnimatedContent(phase, label = "save") { p ->
                when (p) {
                    0 -> Text("Save", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
                    1 -> CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp, modifier = Modifier.size(26.dp))
                    else -> Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(32.dp))
                }
            }
        }
    }
}

@Composable
fun AddRow(text: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.clip(RoundedCornerShape(16.dp)).bounce { onClick() }.padding(horizontal = 6.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(26.dp).clip(CircleShape).background(pal.acc.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Add, null, tint = pal.acc, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(10.dp))
        Text(text, color = pal.acc, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
}
