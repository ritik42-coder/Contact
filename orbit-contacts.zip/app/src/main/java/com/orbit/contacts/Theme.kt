package com.orbit.contacts

import android.app.Activity
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

class Pal(
    val dark: Boolean, val bg: Color, val bg2: Color, val card: Color, val text: Color, val sub: Color,
    val acc: Color, val acc2: Color, val line: Color
)

val Accents = listOf(
    Color(0xFF7C5CFF) to Color(0xFF00D4FF),
    Color(0xFFFF4D8D) to Color(0xFFFFB347),
    Color(0xFF00C896) to Color(0xFF00B3FF),
    Color(0xFFFF7A00) to Color(0xFFFF2D55),
    Color(0xFF4F7BFF) to Color(0xFF9B5CFF),
    Color(0xFF2ECC71) to Color(0xFFF1C40F)
)

val LocalPal = staticCompositionLocalOf<Pal> { error("no palette") }

/** Dark = "Aurora Night" (glass, glow, neon). Light = "Paper Studio" (warm paper, soft shadows, pastels). */
@Composable
fun OrbitTheme(mode: Int, accent: Int, content: @Composable () -> Unit) {
    val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val (a1, a2) = Accents[accent.coerceIn(0, Accents.lastIndex)]
    val spec = tween<Color>(600)
    val bg by animateColorAsState(if (dark) Color(0xFF07080F) else Color(0xFFF7F4EF), spec, label = "bg")
    val bg2 by animateColorAsState(if (dark) Color(0xFF0D0F1C) else Color(0xFFEFE8FA), spec, label = "bg2")
    val card by animateColorAsState(if (dark) Color(0x12FFFFFF) else Color(0xFFFFFFFF), spec, label = "card")
    val text by animateColorAsState(if (dark) Color(0xFFF2F4FA) else Color(0xFF1B1D2A), spec, label = "text")
    val sub by animateColorAsState(if (dark) Color(0xFF9AA3B8) else Color(0xFF6B7080), spec, label = "sub")
    val line by animateColorAsState(if (dark) Color(0x1AFFFFFF) else Color(0x0F000000), spec, label = "line")
    val acc by animateColorAsState(a1, spec, label = "acc")
    val acc2 by animateColorAsState(a2, spec, label = "acc2")
    val pal = Pal(dark, bg, bg2, card, text, sub, acc, acc2, line)
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window
        if (w != null) {
            val c = WindowCompat.getInsetsController(w, view)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }
    val scheme = if (dark) darkColorScheme(primary = acc, background = bg, surface = bg)
    else lightColorScheme(primary = acc, background = bg, surface = bg)
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalPal provides pal) { content() }
    }
}
