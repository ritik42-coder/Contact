package com.orbit.contacts

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.ContactsContract
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {
    private val vm: ContactsVm by viewModels()
    private var launchIntent by mutableStateOf<Intent?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        launchIntent = intent
        val pick = intent?.action == Intent.ACTION_PICK || intent?.action == Intent.ACTION_GET_CONTENT
        setContent {
            OrbitTheme(vm.themeMode, vm.accent) {
                Root(vm, launchIntent, pick) { c ->
                    setResult(Activity.RESULT_OK, Intent().setData(ContactsContract.Contacts.getLookupUri(c.id, c.lookup)))
                    finish()
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        launchIntent = intent
    }
}
