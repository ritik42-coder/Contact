package com.orbit.contacts

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * T9 dial pad. Type digits, it matches both numbers and names (2 = ABC, 3 = DEF ...).
 */
@Composable
fun DialerOverlay(
    show: Boolean,
    vm: ContactsVm,
    onClose: () -> Unit,
    onOpen: (Contact) -> Unit
) {
    val pal = LocalPal.current
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val buzz = rememberBuzz()
    var typed by remember { mutableStateOf("") }

    val hits = remember(typed, vm.contacts) {
        if (typed.isBlank()) emptyList()
        else vm.contacts.filter { c ->
            c.phones.any { digits(it.number).contains(typed) } || t9(c.name).contains(typed)
        }.take(6)
    }
    val exact = remember(typed) { typed.length >= 3 && typed.all { it.isDigit() } }

    fun press(k: String) {
        typed = typed + k
        buzz(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
    }

    AnimatedVisibility(
        visible = show,
        enter = slideInVertically { it } + fadeIn(),
        exit = slideOutVertically { it } + fadeOut()
    ) {
        Box(Modifier.fillMaxSize().background(pal.bg)) {
            LiveBackground()
            Column(
                Modifier.fillMaxSize()
                    .windowInsetsPadding(WindowInsets.systemBars)
                    .padding(horizontal = 20.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconBtn(Icons.Rounded.Close) { typed = ""; onClose() }
                    Spacer(Modifier.weight(1f))
                    Text("Dial pad", color = pal.sub, fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 1.5.sp)
                    Spacer(Modifier.weight(1f))
                    IconBtn(Icons.Rounded.Backspace) { typed = typed.dropLast(1) }
                }

                Spacer(Modifier.height(10.dp))
                Text(
                    if (typed.isEmpty()) "Type a number or a name" else typed,
                    color = if (typed.isEmpty()) pal.sub else pal.text,
                    fontSize = if (typed.isEmpty()) 22.sp else 34.sp,
                    fontWeight = if (typed.isEmpty()) FontWeight.SemiBold else FontWeight.Black,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
                )
                Spacer(Modifier.height(6.dp))

                Box(Modifier.weight(1f).fillMaxWidth()) {
                    if (hits.isNotEmpty()) {
                        LazyColumn(contentPadding = PaddingValues(vertical = 6.dp)) {
                            items(hits, key = { it.id }) { c ->
                                Glass(
                                    Modifier.padding(vertical = 3.dp).fillMaxWidth()
                                        .bounce { typed = ""; onClose(); onOpen(c) },
                                    18.dp
                                ) {
                                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Avatar(c, 36.dp)
                                        Spacer(Modifier.width(10.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(c.name.ifBlank { "(No name)" }, color = pal.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text(c.phones.firstOrNull()?.number ?: "", color = pal.sub, fontSize = 12.sp, maxLines = 1)
                                        }
                                        Icon(Icons.Rounded.ChevronRight, null, tint = pal.sub, modifier = Modifier.size(20.dp))
                                    }
                                }
                            }
                        }
                    } else if (typed.isNotEmpty()) {
                        Text(
                            "No match for $typed",
                            color = pal.sub, fontSize = 14.sp,
                            modifier = Modifier.align(Alignment.TopStart).padding(top = 14.dp, start = 6.dp)
                        )
                    }
                }

                // keys
                val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#")
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (row in keys.chunked(3)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            for (k in row) {
                                Box(
                                    Modifier.size(66.dp).clip(CircleShape).background(pal.card)
                                        .bounce(onLong = { if (k == "0") typed = "" else typed = typed + k }) { press(k) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(k, color = pal.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                                        val letters = when (k) {
                                            "2" -> "ABC"; "3" -> "DEF"; "4" -> "GHI"; "5" -> "JKL"
                                            "6" -> "MNO"; "7" -> "PQRS"; "8" -> "TUV"; "9" -> "WXYZ"
                                            else -> ""
                                        }
                                        if (letters.isNotEmpty()) Text(letters, color = pal.sub, fontSize = 9.sp, letterSpacing = 1.sp)
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    Spacer(Modifier.size(56.dp))
                    val callBg = if (typed.isBlank()) Modifier.background(pal.card)
                    else Modifier.background(Brush.linearGradient(listOf(Color(0xFF22C55E), Color(0xFF16A34A))))
                    Box(
                        Modifier.size(66.dp).clip(CircleShape).then(callBg)
                            .bounce { if (typed.isNotBlank()) callNum(ctx, typed) },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Rounded.Call, null, tint = if (typed.isBlank()) pal.sub else Color.White, modifier = Modifier.size(28.dp)) }
                    Box(
                        Modifier.size(56.dp).clip(CircleShape).background(pal.card)
                            .bounce { if (typed.isNotBlank()) smsNum(ctx, typed) },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Rounded.Sms, null, tint = if (exact) pal.acc else pal.sub, modifier = Modifier.size(22.dp)) }
                }
            }
        }
    }
}
