package com.orbit.contacts

import android.content.ContentProviderOperation
import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds as K
import android.provider.ContactsContract.Data
import android.provider.ContactsContract.RawContacts
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.OutputStream
import java.time.LocalDate
import java.time.temporal.ChronoUnit

data class PhoneNo(val number: String, val type: Int = K.Phone.TYPE_MOBILE)
data class MailAd(val address: String, val type: Int = K.Email.TYPE_HOME)

data class Contact(
    val id: Long, val lookup: String, val name: String, val starred: Boolean, val photo: String?,
    val phones: List<PhoneNo>, val emails: List<MailAd>, val org: String, val title: String,
    val note: String, val birthday: String, val address: String, val website: String, val raws: List<Long>
) {
    val initials: String
        get() {
            val p = name.trim().split(" ").filter { it.isNotEmpty() }
            return when {
                p.isEmpty() -> "#"
                p.size == 1 -> p[0].take(1).uppercase()
                else -> (p.first().take(1) + p.last().take(1)).uppercase()
            }
        }
    val letter: Char
        get() {
            val c = name.trim().firstOrNull()?.uppercaseChar() ?: '#'
            return if (c.isLetter()) c else '#'
        }
    val sortKeyLast: String
        get() = (name.trim().split(" ").lastOrNull() ?: "") + " " + name
}

data class Draft(
    val name: String = "", val org: String = "", val title: String = "",
    val phones: List<PhoneNo> = listOf(PhoneNo("")), val emails: List<MailAd> = emptyList(),
    val note: String = "", val birthday: String = "", val address: String = "", val website: String = "",
    val photo: ByteArray? = null
) {
    companion object {
        fun from(c: Contact) = Draft(
            c.name, c.org, c.title, c.phones.ifEmpty { listOf(PhoneNo("")) }, c.emails,
            c.note, c.birthday, c.address, c.website, null
        )
    }
}

fun phoneLabel(t: Int) = when (t) {
    K.Phone.TYPE_HOME -> "Home"
    K.Phone.TYPE_WORK -> "Work"
    K.Phone.TYPE_MOBILE -> "Mobile"
    K.Phone.TYPE_MAIN -> "Main"
    else -> "Other"
}

fun mailLabel(t: Int) = when (t) {
    K.Email.TYPE_WORK -> "Work"
    K.Email.TYPE_HOME -> "Personal"
    else -> "Other"
}

val PHONE_TYPES = listOf(K.Phone.TYPE_MOBILE, K.Phone.TYPE_HOME, K.Phone.TYPE_WORK, K.Phone.TYPE_OTHER)
val MAIL_TYPES = listOf(K.Email.TYPE_HOME, K.Email.TYPE_WORK, K.Email.TYPE_OTHER)

fun digits(s: String) = s.filter { it.isDigit() }

fun t9(s: String): String = buildString {
    for (ch in s.lowercase()) append(
        when (ch) {
            in 'a'..'c' -> '2'; in 'd'..'f' -> '3'; in 'g'..'i' -> '4'; in 'j'..'l' -> '5'
            in 'm'..'o' -> '6'; in 'p'..'s' -> '7'; in 't'..'v' -> '8'; in 'w'..'z' -> '9'
            in '0'..'9' -> ch
            else -> ' '
        }
    )
}

fun matches(c: Contact, q: String): Boolean {
    if (q.isBlank()) return true
    val s = q.trim().lowercase()
    if (c.name.lowercase().contains(s) || c.org.lowercase().contains(s)) return true
    if (c.emails.any { it.address.lowercase().contains(s) }) return true
    val d = digits(s)
    if (d.isNotEmpty() && c.phones.any { digits(it.number).contains(d) }) return true
    if (s.all { it.isDigit() } && s.length >= 2 && t9(c.name).replace(" ", "").contains(s)) return true
    return false
}

private fun safeDate(y: Int, m: Int, d: Int): LocalDate = try { LocalDate.of(y, m, d) } catch (e: Exception) { LocalDate.of(y, 3, 1) }

fun daysToBirthday(b: String): Int? = try {
    val s = b.trim()
    val dashed = s.startsWith("--")
    val p = (if (dashed) s.drop(2) else s).split("-")
    val m = if (dashed) p[0].toInt() else p[1].toInt()
    val d = if (dashed) p[1].toInt() else p[2].toInt()
    val today = LocalDate.now()
    var next = safeDate(today.year, m, d)
    if (next.isBefore(today)) next = safeDate(today.year + 1, m, d)
    ChronoUnit.DAYS.between(today, next).toInt()
} catch (e: Exception) { null }

fun duplicates(cs: List<Contact>): List<Pair<Contact, Contact>> {
    val out = ArrayList<Pair<Contact, Contact>>()
    val seen = HashSet<Long>()
    val byNum = HashMap<String, MutableList<Contact>>()
    for (c in cs) for (p in c.phones) {
        val d = digits(p.number)
        if (d.length >= 7) byNum.getOrPut(d.takeLast(9)) { ArrayList() }.add(c)
    }
    val byName = HashMap<String, MutableList<Contact>>()
    for (c in cs) if (c.name.isNotBlank() && c.phones.isNotEmpty()) byName.getOrPut(c.name.trim().lowercase()) { ArrayList() }.add(c)
    for (g in byNum.values + byName.values) {
        val u = g.distinctBy { it.id }
        if (u.size > 1) {
            val a = u[0]
            for (i in 1 until u.size) {
                val b = u[i]
                if (seen.add(a.id * 1_000_003L + b.id)) out.add(a to b)
            }
        }
    }
    return out
}

/** Address-book health: score 0..100 and the number of things worth fixing. */
fun health(cs: List<Contact>): Pair<Int, Int> {
    if (cs.isEmpty()) return 100 to 0
    val bad = cs.count { it.phones.isEmpty() && it.emails.isEmpty() } + duplicates(cs).size
    return (100 - (bad * 100 / cs.size)).coerceIn(0, 100) to bad
}

data class CallRec(val tail: String, val type: Int, val date: Long, val dur: Long)

fun tailOf(n: String): String { val d = digits(n); return if (d.length >= 9) d.takeLast(9) else d }

fun buildLast(cs: List<Contact>, cl: List<CallRec>): Map<Long, Long> {
    val latest = HashMap<String, Long>()
    for (c in cl) if (c.tail.isNotEmpty() && c.date > (latest[c.tail] ?: 0L)) latest[c.tail] = c.date
    val out = HashMap<Long, Long>()
    for (c in cs) {
        var best = 0L
        for (p in c.phones) { val t = latest[tailOf(p.number)]; if (t != null && t > best) best = t }
        if (best > 0L) out[c.id] = best
    }
    return out
}

object Thumbs {
    private val cache = LruCache<String, ImageBitmap>(400)
    fun get(k: String): ImageBitmap? = cache.get(k)
    fun load(ctx: Context, uri: String): ImageBitmap? = try {
        ctx.contentResolver.openInputStream(Uri.parse(uri))?.use { s ->
            BitmapFactory.decodeStream(s)?.asImageBitmap()?.also { cache.put(uri, it) }
        }
    } catch (e: Exception) { null }
}

object Repo {
    private class B(val id: Long, val lookup: String, val name: String, val starred: Boolean, val photo: String?) {
        val phones = ArrayList<PhoneNo>()
        val emails = ArrayList<MailAd>()
        var org = ""; var title = ""; var note = ""; var bday = ""; var addr = ""; var web = ""
        val raws = LinkedHashSet<Long>()
    }

    private val MIMES = listOf(
        K.StructuredName.CONTENT_ITEM_TYPE, K.Phone.CONTENT_ITEM_TYPE, K.Email.CONTENT_ITEM_TYPE,
        K.Organization.CONTENT_ITEM_TYPE, K.Note.CONTENT_ITEM_TYPE, K.StructuredPostal.CONTENT_ITEM_TYPE,
        K.Website.CONTENT_ITEM_TYPE, K.Event.CONTENT_ITEM_TYPE, K.Photo.CONTENT_ITEM_TYPE
    )

    fun load(cr: ContentResolver): List<Contact> {
        val m = LinkedHashMap<Long, B>()
        cr.query(
            ContactsContract.Contacts.CONTENT_URI,
            arrayOf(
                ContactsContract.Contacts._ID, ContactsContract.Contacts.LOOKUP_KEY,
                ContactsContract.Contacts.DISPLAY_NAME_PRIMARY, ContactsContract.Contacts.STARRED,
                ContactsContract.Contacts.PHOTO_THUMBNAIL_URI
            ),
            null, null, ContactsContract.Contacts.SORT_KEY_PRIMARY + " COLLATE LOCALIZED ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                m[id] = B(id, c.getString(1) ?: "", c.getString(2) ?: "", c.getInt(3) == 1, c.getString(4))
            }
        }
        cr.query(
            Data.CONTENT_URI,
            arrayOf(Data.CONTACT_ID, Data.MIMETYPE, Data.DATA1, Data.DATA2, Data.DATA4),
            "${Data.MIMETYPE} IN (?,?,?,?,?,?,?)",
            arrayOf(
                K.Phone.CONTENT_ITEM_TYPE, K.Email.CONTENT_ITEM_TYPE, K.Organization.CONTENT_ITEM_TYPE,
                K.Note.CONTENT_ITEM_TYPE, K.StructuredPostal.CONTENT_ITEM_TYPE, K.Website.CONTENT_ITEM_TYPE,
                K.Event.CONTENT_ITEM_TYPE
            ),
            null
        )?.use { c ->
            while (c.moveToNext()) {
                val b = m[c.getLong(0)] ?: continue
                val d1 = c.getString(2) ?: ""
                if (d1.isBlank()) continue
                when (c.getString(1)) {
                    K.Phone.CONTENT_ITEM_TYPE -> if (b.phones.none { digits(it.number) == digits(d1) }) b.phones.add(PhoneNo(d1, c.getInt(3)))
                    K.Email.CONTENT_ITEM_TYPE -> if (b.emails.none { it.address.equals(d1, true) }) b.emails.add(MailAd(d1, c.getInt(3)))
                    K.Organization.CONTENT_ITEM_TYPE -> { if (b.org.isEmpty()) b.org = d1; if (b.title.isEmpty()) b.title = c.getString(4) ?: "" }
                    K.Note.CONTENT_ITEM_TYPE -> if (b.note.isEmpty()) b.note = d1
                    K.StructuredPostal.CONTENT_ITEM_TYPE -> if (b.addr.isEmpty()) b.addr = d1
                    K.Website.CONTENT_ITEM_TYPE -> if (b.web.isEmpty()) b.web = d1
                    K.Event.CONTENT_ITEM_TYPE -> if (c.getInt(3) == K.Event.TYPE_BIRTHDAY && b.bday.isEmpty()) b.bday = d1
                }
            }
        }
        cr.query(RawContacts.CONTENT_URI, arrayOf(RawContacts._ID, RawContacts.CONTACT_ID), "${RawContacts.DELETED}=0", null, null)?.use { c ->
            while (c.moveToNext()) m[c.getLong(1)]?.raws?.add(c.getLong(0))
        }
        return m.values.map {
            Contact(it.id, it.lookup, it.name, it.starred, it.photo, it.phones, it.emails, it.org, it.title, it.note, it.bday, it.addr, it.web, it.raws.toList())
        }
    }

    /** Latest calls, or null when the call-log permission is missing. */
    fun loadCalls(cr: ContentResolver): List<CallRec>? = try {
        val q = Bundle().apply {
            putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(CallLog.Calls.DATE))
            putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
            putInt(ContentResolver.QUERY_ARG_LIMIT, 800)
        }
        val out = ArrayList<CallRec>()
        cr.query(CallLog.Calls.CONTENT_URI, arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION), q, null)?.use { c ->
            while (c.moveToNext()) out.add(CallRec(tailOf(c.getString(0) ?: ""), c.getInt(1), c.getLong(2), c.getLong(3)))
        }
        out
    } catch (e: SecurityException) { null } catch (e: Exception) { emptyList() }

    fun save(cr: ContentResolver, d: Draft, existing: Contact?) {
        val ops = ArrayList<ContentProviderOperation>()
        val raw: Long? = existing?.raws?.firstOrNull()
        if (existing != null && raw != null) {
            for (r in existing.raws) for (mt in MIMES) {
                val sel = if (mt == K.Event.CONTENT_ITEM_TYPE)
                    "${Data.RAW_CONTACT_ID}=? AND ${Data.MIMETYPE}=? AND ${Data.DATA2}=${K.Event.TYPE_BIRTHDAY}"
                else "${Data.RAW_CONTACT_ID}=? AND ${Data.MIMETYPE}=?"
                if (mt == K.Photo.CONTENT_ITEM_TYPE && d.photo == null) continue
                ops.add(ContentProviderOperation.newDelete(Data.CONTENT_URI).withSelection(sel, arrayOf(r.toString(), mt)).build())
            }
        } else {
            ops.add(
                ContentProviderOperation.newInsert(RawContacts.CONTENT_URI)
                    .withValue(RawContacts.ACCOUNT_TYPE, null).withValue(RawContacts.ACCOUNT_NAME, null).build()
            )
        }
        fun row(mime: String, vararg kv: Pair<String, Any?>) {
            val b = ContentProviderOperation.newInsert(Data.CONTENT_URI).withValue(Data.MIMETYPE, mime)
            if (raw != null) b.withValue(Data.RAW_CONTACT_ID, raw) else b.withValueBackReference(Data.RAW_CONTACT_ID, 0)
            for ((k, v) in kv) b.withValue(k, v)
            ops.add(b.build())
        }
        if (d.name.isNotBlank()) row(K.StructuredName.CONTENT_ITEM_TYPE, K.StructuredName.DISPLAY_NAME to d.name.trim())
        for (p in d.phones) if (p.number.isNotBlank()) row(K.Phone.CONTENT_ITEM_TYPE, K.Phone.NUMBER to p.number.trim(), K.Phone.TYPE to p.type)
        for (e in d.emails) if (e.address.isNotBlank()) row(K.Email.CONTENT_ITEM_TYPE, K.Email.ADDRESS to e.address.trim(), K.Email.TYPE to e.type)
        if (d.org.isNotBlank() || d.title.isNotBlank()) row(K.Organization.CONTENT_ITEM_TYPE, K.Organization.COMPANY to d.org.trim(), K.Organization.TITLE to d.title.trim())
        if (d.note.isNotBlank()) row(K.Note.CONTENT_ITEM_TYPE, K.Note.NOTE to d.note.trim())
        if (d.address.isNotBlank()) row(K.StructuredPostal.CONTENT_ITEM_TYPE, K.StructuredPostal.FORMATTED_ADDRESS to d.address.trim())
        if (d.website.isNotBlank()) row(K.Website.CONTENT_ITEM_TYPE, K.Website.URL to d.website.trim())
        if (d.birthday.isNotBlank()) row(K.Event.CONTENT_ITEM_TYPE, K.Event.START_DATE to d.birthday.trim(), K.Event.TYPE to K.Event.TYPE_BIRTHDAY)
        if (d.photo != null) row(K.Photo.CONTENT_ITEM_TYPE, K.Photo.PHOTO to d.photo)
        cr.applyBatch(ContactsContract.AUTHORITY, ops)
    }

    fun delete(cr: ContentResolver, c: Contact) {
        cr.delete(Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_LOOKUP_URI, c.lookup), null, null)
    }

    fun star(cr: ContentResolver, id: Long, v: Boolean) {
        val cv = ContentValues().apply { put(ContactsContract.Contacts.STARRED, if (v) 1 else 0) }
        cr.update(Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_URI, id.toString()), cv, null, null)
    }

    fun merge(cr: ContentResolver, a: Contact, b: Contact) {
        val ops = ArrayList<ContentProviderOperation>()
        for (ra in a.raws) for (rb in b.raws) ops.add(
            ContentProviderOperation.newUpdate(ContactsContract.AggregationExceptions.CONTENT_URI)
                .withValue(ContactsContract.AggregationExceptions.TYPE, ContactsContract.AggregationExceptions.TYPE_KEEP_TOGETHER)
                .withValue(ContactsContract.AggregationExceptions.RAW_CONTACT_ID1, ra)
                .withValue(ContactsContract.AggregationExceptions.RAW_CONTACT_ID2, rb).build()
        )
        if (ops.isNotEmpty()) cr.applyBatch(ContactsContract.AUTHORITY, ops)
    }

    fun exportAll(cr: ContentResolver, lookups: List<String>, out: OutputStream) {
        for (chunk in lookups.chunked(80)) {
            val u = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_MULTI_VCARD_URI, Uri.encode(chunk.joinToString(":")))
            cr.openInputStream(u)?.use { it.copyTo(out) }
        }
    }
}
