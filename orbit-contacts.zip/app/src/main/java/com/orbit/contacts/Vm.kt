package com.orbit.contacts

import android.app.Application
import android.content.Context
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ContactsVm(app: Application) : AndroidViewModel(app) {
    private val cr = app.contentResolver
    private val prefs = app.getSharedPreferences("orbit", Context.MODE_PRIVATE)

    var contacts by mutableStateOf<List<Contact>>(emptyList()); private set
    var loading by mutableStateOf(true); private set
    var granted by mutableStateOf(false)
    var themeMode by mutableIntStateOf(prefs.getInt("mode", 0)); private set
    var accent by mutableIntStateOf(prefs.getInt("acc", 0)); private set
    var sortLast by mutableStateOf(prefs.getBoolean("sortLast", false)); private set
    var fancy by mutableStateOf(prefs.getBoolean("fancy", true)); private set
    var motion by mutableIntStateOf(prefs.getInt("motion", 2)); private set
    var haptics by mutableStateOf(prefs.getBoolean("hap", true)); private set
    var rail by mutableStateOf(prefs.getBoolean("rail", true)); private set
    var compact by mutableStateOf(prefs.getBoolean("compact", false)); private set
    val tags = mutableStateMapOf<String, String>()
    var lastDeleted by mutableStateOf<Draft?>(null)
    var calls by mutableStateOf<List<CallRec>>(emptyList()); private set
    var lastTalk by mutableStateOf<Map<Long, Long>>(emptyMap()); private set
    var callsOk by mutableStateOf(false); private set

    private var started = false
    private var job: Job? = null
    private val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) { reloadSoon() }
    }

    init {
        for ((k, v) in prefs.all) if (k.startsWith("tag:") && v is String) tags[k.removePrefix("tag:")] = v
    }

    // NOTE: these must not be named setAccent/setSortLast/setFancy - those names collide
    // with the JVM setters generated for the accent/sortLast/fancy properties above.
    fun applyMode(i: Int) { themeMode = i; prefs.edit().putInt("mode", i).apply() }
    fun applyAccent(i: Int) { accent = i; prefs.edit().putInt("acc", i).apply() }
    fun applySortLast(b: Boolean) { sortLast = b; prefs.edit().putBoolean("sortLast", b).apply() }
    fun applyFancy(b: Boolean) { fancy = b; prefs.edit().putBoolean("fancy", b).apply() }
    fun applyMotion(i: Int) { motion = i; prefs.edit().putInt("motion", i).apply() }
    fun applyHaptics(b: Boolean) { haptics = b; prefs.edit().putBoolean("hap", b).apply() }
    fun applyRail(b: Boolean) { rail = b; prefs.edit().putBoolean("rail", b).apply() }
    fun applyCompact(b: Boolean) { compact = b; prefs.edit().putBoolean("compact", b).apply() }

    fun start() {
        granted = true
        if (started) return
        started = true
        cr.registerContentObserver(ContactsContract.Contacts.CONTENT_URI, true, obs)
        reload()
    }

    fun reload() {
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { Repo.load(cr) }.getOrElse { emptyList() } }
            val cl = withContext(Dispatchers.IO) { Repo.loadCalls(cr) }
            contacts = r
            callsOk = cl != null
            calls = cl ?: emptyList()
            lastTalk = buildLast(r, calls)
            loading = false
        }
    }

    private fun reloadSoon() {
        job?.cancel()
        job = viewModelScope.launch { delay(350); reload() }
    }

    fun save(d: Draft, existing: Contact?, done: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching { Repo.save(cr, d, existing) }.isSuccess }
            if (ok) reload()
            done(ok)
        }
    }

    fun delete(list: List<Contact>) {
        if (list.size == 1) lastDeleted = Draft.from(list[0])
        viewModelScope.launch {
            withContext(Dispatchers.IO) { for (c in list) runCatching { Repo.delete(cr, c) } }
            for (c in list) setTags(c, emptyList())
            reload()
        }
    }

    fun undo() {
        val d = lastDeleted ?: return
        lastDeleted = null
        save(d, null) {}
    }

    fun star(list: List<Contact>, v: Boolean) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { for (c in list) runCatching { Repo.star(cr, c.id, v) } }
            reload()
        }
    }

    fun merge(a: Contact, b: Contact) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { runCatching { Repo.merge(cr, a, b) } }
            reload()
        }
    }

    fun callsFor(c: Contact): List<CallRec> {
        val tails = c.phones.map { tailOf(it.number) }.toSet()
        return calls.filter { it.tail in tails }.take(6)
    }

    /** Starred or tagged people you have not talked to for three weeks. */
    fun reconnect(): List<Pair<Contact, Long?>> {
        if (!callsOk) return emptyList()
        val now = System.currentTimeMillis()
        val limit = 21L * 86400000L
        return contacts.filter { (it.starred || tagsOf(it).isNotEmpty()) && it.phones.isNotEmpty() }
            .map { it to lastTalk[it.id] }
            .filter { it.second == null || now - it.second!! > limit }
            .sortedBy { it.second ?: 0L }.take(10)
    }

    fun tagsOf(c: Contact): List<String> = tags[c.lookup]?.split(",")?.filter { it.isNotBlank() } ?: emptyList()

    fun setTags(c: Contact, list: List<String>) {
        val s = list.joinToString(",")
        if (s.isEmpty()) { tags.remove(c.lookup); prefs.edit().remove("tag:" + c.lookup).apply() }
        else { tags[c.lookup] = s; prefs.edit().putString("tag:" + c.lookup, s).apply() }
    }

    fun allTags(): List<String> = tags.values.flatMap { it.split(",") }.filter { it.isNotBlank() }.distinct().sorted()

    fun export(uri: Uri, done: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    cr.openOutputStream(uri)?.use { Repo.exportAll(cr, contacts.map { it.lookup }, it) }
                }.isSuccess
            }
            done(ok)
        }
    }

    override fun onCleared() { cr.unregisterContentObserver(obs) }
}
