package com.orbit.contacts

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

sealed interface Screen {
    data object Home : Screen
    data class Detail(val id: Long) : Screen
    data class Edit(val id: Long?, val prefill: Draft? = null) : Screen
    data object Cleanup : Screen
    data object Settings : Screen
}

private fun depth(s: Screen) = when (s) { Screen.Home -> 0; is Screen.Detail -> 1; else -> 2 }

private val ALL_PERMS = arrayOf(
    Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS,
    Manifest.permission.CALL_PHONE, Manifest.permission.READ_CALL_LOG
)

private fun hasRead(ctx: android.content.Context) =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

@Composable
fun Root(vm: ContactsVm, startIntent: Intent?, pick: Boolean, onPick: (Contact) -> Unit) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val quick = (startIntent?.action != null && startIntent.action != Intent.ACTION_MAIN) || !vm.fancy
    val p = remember { Animatable(if (quick) 1f else 0f) }
    var introDone by remember { mutableStateOf(quick) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasRead(ctx)) { vm.start(); vm.reload() }
    }
    LaunchedEffect(Unit) {
        val has = hasRead(ctx)
        if (has) vm.start()
        if (!quick) {
            // let the data and first composition settle so the intro never stutters
            withTimeoutOrNull(900) { snapshotFlow { vm.loading }.first { !it } }
            delay(80)
            launch { snapshotFlow { p.value }.first { it >= 0.66f }; haptic.performHapticFeedback(HapticFeedbackType.LongPress) }
            p.animateTo(1f, tween(3600, easing = LinearEasing))
            introDone = true
        }
        if (!has) perm.launch(ALL_PERMS)
    }

    val stack = remember { mutableStateListOf<Screen>(Screen.Home) }
    var origin by remember { mutableStateOf(TransformOrigin.Center) }
    fun push(s: Screen, o: TransformOrigin = TransformOrigin.Center) { origin = o; stack.add(s) }
    fun pop() { if (stack.size > 1) stack.removeAt(stack.lastIndex) }
    BackHandler(enabled = stack.size > 1) { pop() }

    // system intents: view / edit / insert like the stock Contacts app
    var handled by remember(startIntent) { mutableStateOf(false) }
    LaunchedEffect(startIntent, vm.contacts) {
        if (startIntent == null || handled) return@LaunchedEffect
        when (startIntent.action) {
            Intent.ACTION_INSERT, Intent.ACTION_INSERT_OR_EDIT -> {
                handled = true
                val phone = startIntent.getStringExtra(ContactsContract.Intents.Insert.PHONE) ?: ""
                val mail = startIntent.getStringExtra(ContactsContract.Intents.Insert.EMAIL)
                push(Screen.Edit(null, Draft(name = startIntent.getStringExtra(ContactsContract.Intents.Insert.NAME) ?: "", phones = listOf(PhoneNo(phone)), emails = if (mail != null) listOf(MailAd(mail)) else emptyList())))
            }
            Intent.ACTION_VIEW, Intent.ACTION_EDIT -> {
                val seg = startIntent.data?.pathSegments
                if (seg != null && vm.contacts.isNotEmpty()) {
                    handled = true
                    val id = seg.lastOrNull()?.toLongOrNull()
                    val c = vm.contacts.firstOrNull { it.id == id } ?: vm.contacts.firstOrNull { seg.contains(it.lookup) }
                    if (c != null) push(if (startIntent.action == Intent.ACTION_EDIT) Screen.Edit(c.id) else Screen.Detail(c.id))
                }
            }
        }
    }

    Box(Modifier.fillMaxSize().background(pal.bg)) {
        Box(Modifier.fillMaxSize().graphicsLayer {
            val f = easeOut(0.84f, 1f, p.value)
            shape = RevealShape(f)
            clip = f < 0.999f
            alpha = if (f > 0f) 1f else 0f
            val s = 1.05f - 0.05f * f
            scaleX = s; scaleY = s
        }) {
            SharedBackground()
            if (!vm.granted && introDone) {
                PermissionScreen { perm.launch(ALL_PERMS) }
            } else {
                AnimatedContent(
                    targetState = stack.last(), label = "nav",
                    transitionSpec = {
                        if (depth(targetState) > depth(initialState))
                            (fadeIn(tween(320)) + scaleIn(spring(0.85f, 300f), initialScale = 0.86f, transformOrigin = origin)) togetherWith
                                (fadeOut(tween(220)) + scaleOut(tween(320), targetScale = 1.08f))
                        else
                            (fadeIn(tween(300)) + scaleIn(tween(360), initialScale = 1.08f)) togetherWith
                                (fadeOut(tween(220)) + scaleOut(tween(320), targetScale = 0.86f, transformOrigin = origin))
                    }
                ) { s ->
                    when (s) {
                        Screen.Home -> HomeScreen(
                            vm, pick,
                            onOpen = { c, o -> push(Screen.Detail(c.id), o) },
                            onNew = { push(Screen.Edit(null)) },
                            onCleanup = { push(Screen.Cleanup) },
                            onSettings = { push(Screen.Settings) },
                            onPick = onPick
                        )
                        is Screen.Detail -> DetailScreen(vm, s.id, onBack = { pop() }, onEdit = { c -> push(Screen.Edit(c.id)) })
                        is Screen.Edit -> EditScreen(vm, s.id, s.prefill, onClose = { pop() })
                        Screen.Cleanup -> CleanupScreen(vm, onBack = { pop() }, onOpen = { c -> push(Screen.Detail(c.id)) })
                        Screen.Settings -> SettingsScreen(vm, onBack = { pop() })
                    }
                }
            }
            val del = vm.lastDeleted
            LaunchedEffect(del) { if (del != null) { delay(6000); if (vm.lastDeleted === del) vm.lastDeleted = null } }
            AnimatedVisibility(
                del != null, modifier = Modifier.align(Alignment.BottomCenter),
                enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()
            ) {
                Glass(Modifier.navigationBarsPadding().padding(16.dp).padding(bottom = 70.dp), 22.dp) {
                    Row(Modifier.padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Contact deleted", color = pal.text, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.width(18.dp))
                        Text("UNDO", color = pal.acc, fontWeight = FontWeight.Black, modifier = Modifier.bounce { vm.undo() }.padding(6.dp))
                    }
                }
            }
        }
        if (!introDone) {
            Box(Modifier.fillMaxSize().graphicsLayer {
                val r = sm(0.86f, 1f, p.value)
                alpha = 1f - r
                scaleX = 1f + 0.05f * r; scaleY = scaleX
            }) {
                IntroCanvas(p) { scope.launch { if (p.value < 0.88f) p.animateTo(1f, tween(650)) } }
            }
        }
    }
}

@Composable
fun PermissionScreen(onGrant: () -> Unit) {
    val pal = LocalPal.current
    Box(Modifier.fillMaxSize()) {
        LiveBackground()
        Column(Modifier.fillMaxSize().padding(36.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(110.dp).enter(0).clip(CircleShape).background(Brush.linearGradient(listOf(pal.acc, pal.acc2))), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Person, null, tint = Color.White, modifier = Modifier.size(56.dp))
            }
            Spacer(Modifier.height(28.dp))
            Text("Bring your people in", color = pal.text, fontSize = 28.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, modifier = Modifier.enter(1))
            Spacer(Modifier.height(10.dp))
            Text("Orbit needs access to your contacts (and the phone, to place calls). Everything stays on your device.", color = pal.sub, fontSize = 15.sp, textAlign = TextAlign.Center, modifier = Modifier.enter(2))
            Spacer(Modifier.height(30.dp))
            Text(
                "Allow access", color = Color.White, fontWeight = FontWeight.Black, fontSize = 17.sp,
                modifier = Modifier.enter(3).clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(pal.acc, pal.acc2))).bounce { onGrant() }.padding(horizontal = 34.dp, vertical = 16.dp)
            )
        }
    }
}
