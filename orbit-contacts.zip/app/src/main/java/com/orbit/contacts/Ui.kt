@file:OptIn(ExperimentalFoundationApi::class)

package com.orbit.contacts

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.absoluteValue
import kotlin.math.cos
import kotlin.math.sin

fun sm(a: Float, b: Float, t: Float): Float {
    val x = ((t - a) / (b - a)).coerceIn(0f, 1f)
    return x * x * (3f - 2f * x)
}

fun lf(a: Float, b: Float, t: Float) = a + (b - a) * t

/** Springy press feedback + optional long press. */
fun Modifier.bounce(onLong: (() -> Unit)? = null, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.95f else 1f, spring(dampingRatio = 0.45f, stiffness = 700f), label = "press")
    this
        .graphicsLayer { scaleX = s; scaleY = s }
        .combinedClickable(interactionSource = src, indication = null, onLongClick = onLong, onClick = onClick)
}

/** Staggered entrance: slides up, scales in and fades with a spring. */
@Composable
fun Modifier.enter(i: Int, key: Any = Unit): Modifier {
    val a = remember(key) { Animatable(0f) }
    LaunchedEffect(key) {
        delay(i * 55L)
        a.animateTo(1f, spring(dampingRatio = 0.72f, stiffness = 240f))
    }
    return this.graphicsLayer {
        val v = a.value
        alpha = v.coerceIn(0f, 1f)
        translationY = (1f - v) * 70f
        scaleX = 0.92f + 0.08f * v
        scaleY = 0.92f + 0.08f * v
    }
}

@Composable
fun rememberThumb(uri: String?): ImageBitmap? {
    val ctx = LocalContext.current
    val st = produceState<ImageBitmap?>(initialValue = uri?.let { Thumbs.get(it) }, uri) {
        value = if (uri == null) null else (Thumbs.get(uri) ?: withContext(Dispatchers.IO) { Thumbs.load(ctx, uri) })
    }
    return st.value
}

@Composable
fun Avatar(c: Contact, size: Dp, modifier: Modifier = Modifier, preview: ImageBitmap? = null) {
    val pal = LocalPal.current
    val bmp = preview ?: rememberThumb(c.photo)
    val h = (c.name.hashCode().absoluteValue % 360).toFloat()
    val g = Brush.linearGradient(
        listOf(
            Color.hsv(h, if (pal.dark) 0.65f else 0.42f, if (pal.dark) 0.95f else 1f),
            Color.hsv((h + 40f) % 360f, if (pal.dark) 0.8f else 0.55f, if (pal.dark) 0.75f else 0.97f)
        )
    )
    Box(modifier.size(size).clip(CircleShape).background(g), contentAlignment = Alignment.Center) {
        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(c.initials, color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.36f).sp)
    }
}

/** Dark: living aurora. Light: drifting pastel paper blobs. Both react to scroll. */
@Composable
fun LiveBackground(scroll: () -> Float = { 0f }) {
    val pal = LocalPal.current
    val inf = rememberInfiniteTransition(label = "bg")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(26000, easing = LinearEasing)), label = "t")
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(pal.bg, pal.bg2)))
        val w = size.width
        val h = size.height
        val s = scroll() * 0.12f
        val a = (t * 2.0 * PI).toFloat()
        fun blob(cx: Float, cy: Float, r: Float, c: Color) {
            drawCircle(Brush.radialGradient(listOf(c, Color.Transparent), center = Offset(cx, cy), radius = r), radius = r, center = Offset(cx, cy))
        }
        if (pal.dark) {
            blob(w * (0.2f + 0.15f * sin(a)), h * 0.18f - s, w * 0.85f, pal.acc.copy(alpha = 0.30f))
            blob(w * (0.85f - 0.2f * cos(a)), h * 0.42f - s * 0.6f, w * 0.8f, pal.acc2.copy(alpha = 0.20f))
            blob(w * (0.4f + 0.2f * sin(a + 2f)), h * 0.85f - s * 0.3f, w * 0.9f, pal.acc.copy(alpha = 0.18f))
        } else {
            blob(w * (0.15f + 0.12f * sin(a)), h * 0.12f - s, w * 0.8f, pal.acc.copy(alpha = 0.22f))
            blob(w * (0.9f - 0.15f * cos(a)), h * 0.5f - s * 0.6f, w * 0.75f, pal.acc2.copy(alpha = 0.20f))
            blob(w * (0.35f + 0.15f * sin(a + 1.5f)), h * 0.95f - s * 0.3f, w * 0.85f, Color(0x33FFB3C7))
        }
    }
}

/** Dark = frosted glass with a glowing edge. Light = white card with a soft shadow. */
@Composable
fun Glass(modifier: Modifier = Modifier, radius: Dp = 22.dp, content: @Composable BoxScope.() -> Unit) {
    val pal = LocalPal.current
    val sh = RoundedCornerShape(radius)
    val m = if (pal.dark)
        modifier.clip(sh).background(pal.card).border(1.dp, Brush.linearGradient(listOf(Color(0x33FFFFFF), Color(0x08FFFFFF))), sh)
    else
        modifier.shadow(10.dp, sh, ambientColor = Color(0x1A5B4B8A), spotColor = Color(0x1A5B4B8A)).clip(sh).background(pal.card)
    Box(m, content = content)
}

@Composable
fun IconBtn(icon: ImageVector, modifier: Modifier = Modifier, tint: Color? = null, filled: Boolean = false, onClick: () -> Unit) {
    val pal = LocalPal.current
    val bgc = if (filled) Brush.linearGradient(listOf(pal.acc, pal.acc2)) else Brush.linearGradient(listOf(pal.card, pal.card))
    Box(
        modifier.size(44.dp).clip(CircleShape).background(bgc).bounce(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = tint ?: if (filled) Color.White else pal.text, modifier = Modifier.size(22.dp)) }
}
