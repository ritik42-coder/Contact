@file:OptIn(ExperimentalFoundationApi::class)

package com.orbit.contacts

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.absoluteValue
import kotlin.math.cos
import kotlin.math.sin

fun sm(a: Float, b: Float, t: Float): Float {
    val x = ((t - a) / (b - a)).coerceIn(0f, 1f)
    return x * x * (3f - 2f * x)
}

fun lf(a: Float, b: Float, t: Float) = a + (b - a) * t

/** Springy press feedback + optional long press. */
fun Modifier.bounce(onLong: (() -> Unit)? = null, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.95f else 1f, spring(dampingRatio = 0.45f, stiffness = 700f), label = "press")
    this
        .graphicsLayer { scaleX = s; scaleY = s }
        .combinedClickable(interactionSource = src, indication = null, onLongClick = onLong, onClick = onClick)
}

/** Staggered entrance: slides up, scales in and fades with a spring. */
@Composable
fun Modifier.enter(i: Int, key: Any = Unit): Modifier {
    val a = remember(key) { Animatable(0f) }
    LaunchedEffect(key) {
        delay(i * 55L)
        a.animateTo(1f, spring(dampingRatio = 0.72f, stiffness = 240f))
    }
    return this.graphicsLayer {
        val v = a.value
        alpha = v.coerceIn(0f, 1f)
        translationY = (1f - v) * 70f
        scaleX = 0.92f + 0.08f * v
        scaleY = 0.92f + 0.08f * v
    }
}

@Composable
fun rememberThumb(uri: String?): ImageBitmap? {
    val ctx = LocalContext.current
    val st = produceState<ImageBitmap?>(initialValue = uri?.let { Thumbs.get(it) }, uri) {
        value = if (uri == null) null else (Thumbs.get(uri) ?: withContext(Dispatchers.IO) { Thumbs.load(ctx, uri) })
    }
    return st.value
}

@Composable
fun Avatar(c: Contact, size: Dp, modifier: Modifier = Modifier, preview: ImageBitmap? = null) {
    val pal = LocalPal.current
    val bmp = preview ?: rememberThumb(c.photo)
    val g = remember(c.name, pal.dark) {
        val h = (c.name.hashCode().absoluteValue % 360).toFloat()
        Brush.linearGradient(
            listOf(
                Color.hsv(h, if (pal.dark) 0.65f else 0.42f, if (pal.dark) 0.95f else 1f),
                Color.hsv((h + 40f) % 360f, if (pal.dark) 0.8f else 0.55f, if (pal.dark) 0.75f else 0.97f)
            )
        )
    }
    Box(modifier.size(size).clip(CircleShape).background(g), contentAlignment = Alignment.Center) {
        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(c.initials, color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.36f).sp)
    }
}

class ScrollBus { var y by mutableFloatStateOf(0f) }
val LocalBus = staticCompositionLocalOf { ScrollBus() }

/** Scroll velocity (smoothed) used for the depth-parallax effect on list rows. */
class ScrollFx { var v by mutableFloatStateOf(0f) }

/** Screens call this to feed their scroll position to the one shared background. */
@Composable
fun LiveBackground(scroll: () -> Float = { 0f }) {
    val bus = LocalBus.current
    LaunchedEffect(scroll) { snapshotFlow { scroll() }.collect { bus.y = it } }
}

@Composable
private fun Blob(size: Dp, brush: Brush, fx: Float, fy: Float, move: () -> Offset) {
    Box(
        Modifier.offset(x = size * fx, y = size * fy).size(size)
            .graphicsLayer { val o = move(); translationX = o.x; translationY = o.y }
            .background(brush)
    )
}

/**
 * One living background for the whole app.
 * Everything is drawn once into cached brushes / a single Canvas and only moved with layer
 * translations, so it stays at 60fps even while the list is scrolling.
 * The motion setting decides how much of it is switched on.
 */
@Composable
fun SharedBackground() {
    val pal = LocalPal.current
    val bus = LocalBus.current
    val motion = LocalMotion.current
    val sw = LocalConfiguration.current.screenWidthDp.dp
    val dur = if (motion.cinematic) 26000 else 56000

    val inf = rememberInfiniteTransition(label = "bg")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(dur, easing = LinearEasing)), label = "t")

    // brushes are built once per palette change - never per frame
    val sky = remember(pal.bg, pal.bg2) { Brush.verticalGradient(listOf(pal.bg, pal.bg2)) }
    val b1 = remember(pal.acc, pal.dark) {
        Brush.radialGradient(listOf(pal.acc.copy(alpha = if (pal.dark) 0.34f else 0.26f), Color.Transparent))
    }
    val b2 = remember(pal.acc2, pal.dark) {
        Brush.radialGradient(listOf(pal.acc2.copy(alpha = if (pal.dark) 0.24f else 0.22f), Color.Transparent))
    }
    val b3 = remember(pal.acc, pal.dark) {
        Brush.radialGradient(
            listOf(
                (if (pal.dark) pal.acc else Color(0xFFFFB3C7)).copy(alpha = if (pal.dark) 0.20f else 0.28f),
                Color.Transparent
            )
        )
    }
    val scrim = remember(pal.bg) {
        Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent, pal.bg.copy(alpha = 0.55f)))
    }

    Box(Modifier.fillMaxSize().background(sky)) {
        // aurora blobs - GPU translated only
        Blob(sw * 1.7f, b1, -0.45f, -0.35f) {
            val a = t * 6.2832f
            Offset(sin(a) * 80f, cos(a) * 60f - bus.y * 0.12f)
        }
        Blob(sw * 1.5f, b2, 0.15f, 0.25f) {
            val a = t * 6.2832f
            Offset(-cos(a) * 90f, sin(a) * 70f - bus.y * 0.07f)
        }
        Blob(sw * 1.6f, b3, -0.2f, 0.85f) {
            val a = t * 6.2832f + 2f
            Offset(sin(a) * 70f, cos(a) * 50f - bus.y * 0.04f)
        }

        // orbit rings - the app's "orbit" idea, very cheap (two arcs)
        if (motion.animated) Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width * 0.5f, size.height * 0.42f)
            val r = size.minDimension * 0.62f
            for (i in 0 until 2) {
                val start = t * 360f + i * 155f
                drawArc(
                    brush = Brush.sweepGradient(
                        listOf(Color.Transparent, pal.acc.copy(alpha = 0.45f * motion.k), Color.Transparent),
                        center = c
                    ),
                    startAngle = start, sweepAngle = 120f, useCenter = false,
                    topLeft = Offset(c.x - r, c.y - r),
                    size = Size(r * 2f, r * 2f),
                    style = Stroke((1.2f + i * 0.4f).dp.toPx())
                )
            }
        }

        // drifting dust / paper specks
        if (motion.cinematic) Canvas(Modifier.fillMaxSize()) {
            val dust = if (pal.dark) Color.White else pal.acc
            for (i in 0 until 24) {
                val sx = ((i * 0.618f * 7.13f) % 1f) * size.width
                val baseY = ((i * 0.618f * 3.71f) % 1f) * size.height
                val shift = bus.y * (0.04f + 0.05f * (i % 3))
                val y = ((baseY - shift) % size.height + size.height) % size.height
                val r = (0.9f + (i % 3) * 0.7f).dp.toPx()
                val tw = (sin(t * 6.2832f + i) + 1f) / 2f
                drawCircle(dust.copy(alpha = 0.10f + 0.30f * tw), r, Offset(sx, y))
            }
        }

        Box(Modifier.fillMaxSize().background(scrim))
    }
}

/** Dark = frosted glass with a glowing edge. Light = white card with a soft shadow. */
@Composable
fun Glass(modifier: Modifier = Modifier, radius: Dp = 22.dp, content: @Composable BoxScope.() -> Unit) {
    val pal = LocalPal.current
    val sh = RoundedCornerShape(radius)
    val m = if (pal.dark)
        modifier.clip(sh).background(pal.card).border(1.dp, Brush.linearGradient(listOf(Color(0x33FFFFFF), Color(0x08FFFFFF))), sh)
    else
        modifier.shadow(10.dp, sh, ambientColor = Color(0x1A5B4B8A), spotColor = Color(0x1A5B4B8A)).clip(sh).background(pal.card)
    Box(m, content = content)
}

@Composable
fun IconBtn(icon: ImageVector, modifier: Modifier = Modifier, tint: Color? = null, filled: Boolean = false, onClick: () -> Unit) {
    val pal = LocalPal.current
    val bgc = if (filled) Brush.linearGradient(listOf(pal.acc, pal.acc2)) else Brush.linearGradient(listOf(pal.card, pal.card))
    Box(
        modifier.size(44.dp).clip(CircleShape).background(bgc).bounce(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = tint ?: if (filled) Color.White else pal.text, modifier = Modifier.size(22.dp)) }
}
