package com.orbit.contacts

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CallMade
import androidx.compose.material.icons.rounded.CallMissed
import androidx.compose.material.icons.rounded.CallReceived
import androidx.compose.material.icons.rounded.History
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import kotlin.math.hypot

fun vcardText(c: Contact): String = buildString {
    append("BEGIN:VCARD\nVERSION:3.0\n")
    append("FN:").append(c.name).append('\n')
    append("N:;").append(c.name).append(";;;\n")
    for (p in c.phones) append("TEL;TYPE=CELL:").append(p.number).append('\n')
    for (e in c.emails) append("EMAIL:").append(e.address).append('\n')
    if (c.org.isNotBlank()) append("ORG:").append(c.org).append('\n')
    if (c.title.isNotBlank()) append("TITLE:").append(c.title).append('\n')
    append("END:VCARD")
}

private class QrBits(val n: Int, val bits: BooleanArray) { fun at(x: Int, y: Int) = bits[y * n + x] }

private fun makeQr(text: String): QrBits? = try {
    val hints = mapOf<EncodeHintType, Any>(EncodeHintType.MARGIN to 0, EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M)
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 1, 1, hints)
    val n = m.width
    QrBits(n, BooleanArray(n * n) { m.get(it % n, it / n) })
} catch (e: Exception) { null }

/** Scan-to-save: the code blooms outward from the middle, module by module. */
@Composable
fun QrOverlay(show: Boolean, c: Contact, onClose: () -> Unit) {
    AnimatedVisibility(show, enter = fadeIn(tween(220)) + scaleIn(tween(300), initialScale = 0.92f), exit = fadeOut(tween(180))) {
        val qr = remember(c) { makeQr(vcardText(c)) }
        val prog = remember { Animatable(0f) }
        LaunchedEffect(Unit) { prog.animateTo(1f, tween(1300, easing = FastOutSlowInEasing)) }
        Box(
            Modifier.fillMaxSize().background(Color(0xB3000000)).pointerInput(Unit) { detectTapGestures { onClose() } },
            contentAlignment = Alignment.Center
        ) {
            Column(Modifier.clip(RoundedCornerShape(28.dp)).background(Color.White).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Canvas(Modifier.size(260.dp)) {
                    val q = qr
                    if (q != null) {
                        val cell = size.width / q.n
                        val mid = q.n / 2f
                        val maxD = mid * 1.42f
                        val t = prog.value * 1.5f
                        for (y in 0 until q.n) for (x in 0 until q.n) if (q.at(x, y)) {
                            val d = hypot(x + 0.5f - mid, y + 0.5f - mid) / maxD
                            val s = ((t - d) / 0.35f).coerceIn(0f, 1f)
                            if (s > 0f) {
                                val sz = cell * (0.55f + 0.45f * s)
                                drawRoundRect(
                                    Color(0xFF111111), Offset(x * cell + (cell - sz) / 2f, y * cell + (cell - sz) / 2f),
                                    Size(sz, sz), CornerRadius(sz * 0.28f), alpha = s
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text(c.name.ifBlank { "Contact" }, color = Color(0xFF111111), fontSize = 20.sp, fontWeight = FontWeight.Black)
                Text("Point another phone's camera here to save this contact", color = Color(0xFF666666), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.width(260.dp).padding(top = 4.dp))
            }
        }
    }
}

@Composable
fun HistoryCard(hist: List<CallRec>, i: Int, key: Any) {
    val pal = LocalPal.current
    Glass(Modifier.enter(i, key).padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth(), 20.dp) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.History, null, tint = pal.acc, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("RECENT ACTIVITY", color = pal.sub, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            }
            for (h in hist) {
                Row(Modifier.padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    val missed = h.type == 3
                    val col = if (missed) Color(0xFFEF4444) else pal.acc
                    Box(Modifier.size(32.dp).clip(CircleShape).background(col.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
                        Icon(
                            when (h.type) { 1 -> Icons.Rounded.CallReceived; 3 -> Icons.Rounded.CallMissed; else -> Icons.Rounded.CallMade },
                            null, tint = col, modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(when (h.type) { 1 -> "Incoming"; 2 -> "Outgoing"; 3 -> "Missed"; 5 -> "Declined"; else -> "Call" }, color = pal.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        if (h.dur > 0) Text("${h.dur / 60}m ${h.dur % 60}s", color = pal.sub, fontSize = 12.sp)
                    }
                    Text(ago(h.date) + " ago", color = pal.sub, fontSize = 12.sp)
                }
            }
        }
    }
}
