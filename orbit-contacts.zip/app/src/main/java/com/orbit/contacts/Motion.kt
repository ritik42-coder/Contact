package com.orbit.contacts

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.InfiniteTransition
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * App-wide motion settings.
 * level 0 = calm (decorative motion off, best for weak devices)
 * level 1 = balanced (lighter springs, no 3D tilt)
 * level 2 = full cinematic
 */
data class Motion(val level: Int = 2, val haptics: Boolean = true) {
    /** 0f..1f multiplier for decorative animation strength. */
    val k: Float get() = when (level) { 0 -> 0f; 1 -> 0.6f; else -> 1f }
    val animated: Boolean get() = level >= 1
    val cinematic: Boolean get() = level >= 2
}

val LocalMotion = staticCompositionLocalOf { Motion() }

/** Haptic helper that respects the user's haptics setting. */
@Composable
fun rememberBuzz(): (HapticFeedbackType) -> Unit {
    val h = LocalHapticFeedback.current
    val on = LocalMotion.current.haptics
    return remember(h, on) { { t: HapticFeedbackType -> if (on) h.performHapticFeedback(t) } }
}

/** Animated integer counter. */
@Composable
fun AnimatedInt(value: Int, color: Color, size: TextUnit, weight: FontWeight = FontWeight.Black) {
    val a by animateFloatAsState(value.toFloat(), spring(dampingRatio = 0.85f, stiffness = 220f), label = "cnt")
    Text(a.roundToInt().toString(), color = color, fontSize = size, fontWeight = weight)
}

/** Thin animated scroll bar with a draggable thumb - sits on the screen edge. */
@Composable
fun ScrollRail(state: LazyListState, modifier: Modifier = Modifier) {
    val pal = LocalPal.current
    val motion = LocalMotion.current
    val buzz = rememberBuzz()
    val scope = rememberCoroutineScope()
    var h by remember { mutableFloatStateOf(1f) }
    var dragging by remember { mutableStateOf(false) }

    val prog = remember(state) {
        derivedStateOf {
            val li = state.layoutInfo
            val total = li.totalItemsCount
            val first = li.visibleItemsInfo.firstOrNull()
            if (total <= 1 || first == null) 0f
            else {
                val frac = if (first.size > 0) first.offset.toFloat() / first.size else 0f
                ((first.index + frac) / (total - 1)).coerceIn(0f, 1f)
            }
        }
    }
    val vis = remember(state) {
        derivedStateOf {
            val li = state.layoutInfo
            if (li.totalItemsCount <= 0) 1f
            else (li.visibleItemsInfo.size.toFloat() / li.totalItemsCount).coerceIn(0.07f, 1f)
        }
    }
    val active by animateFloatAsState(
        if (dragging || state.isScrollInProgress) 1f else 0f,
        spring(dampingRatio = 0.6f, stiffness = 420f), label = "rail"
    )

    fun scrub(y: Float) {
        val frac = (y / h).coerceIn(0f, 1f)
        val total = state.layoutInfo.totalItemsCount
        if (total > 1) scope.launch {
            state.scrollToItem((frac * (total - 1)).roundToInt().coerceIn(0, total - 1))
        }
    }

    Box(
        modifier.width(16.dp).fillMaxHeight()
            .onSizeChanged { h = it.height.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { o -> dragging = true; buzz(HapticFeedbackType.LongPress); scrub(o.y) },
                    onDragEnd = { dragging = false },
                    onDragCancel = { dragging = false }
                ) { ch, _ -> ch.consume(); scrub(ch.position.y) }
            }
            .pointerInput(Unit) { detectTapGestures { o -> scrub(o.y) } }
            .drawBehind {
                val a = active
                val thick = 3.dp.toPx() + 5.dp.toPx() * a * (0.5f + 0.5f * motion.k)
                val cx = size.width / 2f
                drawRoundRect(
                    color = pal.line,
                    topLeft = Offset(cx - 1.5.dp.toPx(), 0f),
                    size = Size(3.dp.toPx(), size.height),
                    cornerRadius = CornerRadius(1.5.dp.toPx())
                )
                val thumbH = (size.height * vis.value).coerceAtLeast(42.dp.toPx())
                val top = (size.height - thumbH) * prog.value
                drawRoundRect(
                    brush = Brush.verticalGradient(listOf(pal.acc, pal.acc2, pal.acc)),
                    topLeft = Offset(cx - thick / 2f, top),
                    size = Size(thick, thumbH),
                    cornerRadius = CornerRadius(thick / 2f)
                )
            }
    )
}

/** Circular "back to top" button with a scroll-progress ring. */
@Composable
fun ScrollTopButton(visible: Boolean, progress: () -> Float, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val pal = LocalPal.current
    val s by animateFloatAsState(if (visible) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 380f), label = "stb")
    if (s <= 0.02f) return
    Box(
        modifier.size(50.dp)
            .graphicsLayer { scaleX = s; scaleY = s; alpha = s.coerceIn(0f, 1f) }
            .clip(CircleShape)
            .background(pal.card)
            .drawBehind {
                val sw = 3.dp.toPx()
                val tl = Offset(sw / 2f, sw / 2f)
                val sz = Size(size.width - sw, size.height - sw)
                drawArc(color = pal.line, startAngle = -90f, sweepAngle = 360f, useCenter = false, topLeft = tl, size = sz, style = Stroke(sw))
                drawArc(
                    brush = Brush.sweepGradient(listOf(pal.acc, pal.acc2, pal.acc)),
                    startAngle = -90f, sweepAngle = 360f * progress().coerceIn(0f, 1f), useCenter = false,
                    topLeft = tl, size = sz, style = Stroke(sw, cap = StrokeCap.Round)
                )
            }
            .bounce { onClick() },
        contentAlignment = Alignment.Center
    ) { Icon(Icons.Rounded.KeyboardArrowUp, null, tint = pal.acc, modifier = Modifier.size(24.dp)) }
}

/** Tiny animated equaliser used as a "live" indicator. */
@Composable
fun LiveBars(color: Color, barHeight: Dp = 14.dp) {
    val inf = rememberInfiniteTransition(label = "lb")
    LiveBarsInner(color, barHeight, inf)
}

@Composable
private fun LiveBarsInner(color: Color, barHeight: Dp, inf: InfiniteTransition) {
    Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
        for (i in 0 until 3) {
            val v by inf.animateFloat(
                0.3f, 1f,
                infiniteRepeatable(tween(520 + i * 160, easing = FastOutSlowInEasing), RepeatMode.Reverse),
                label = "b$i"
            )
            Box(Modifier.width(3.dp).height(barHeight * v).clip(CircleShape).background(color))
        }
    }
}
