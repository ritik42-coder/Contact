# Orbit Contacts — native Android contacts app (Kotlin + Jetpack Compose, no WebView)

## Build the APK on GitHub (no computer needed)
1. Create a new GitHub repository and upload **all files from this zip** (the folder contents, including `.github`).
   (Or upload the zip itself — the workflow unzips it automatically.)
2. Open **Actions → Build APK → Run workflow** (it also runs on every upload).
3. When it finishes, open the run and download the **Orbit-Contacts-APK** artifact. Unzip it and install `app-debug.apk`.

## What's new in 1.2 (smoothness + motion pass)
- **Motion levels** (Settings → Motion & feel): **Calm** turns off decorative motion (best on older phones), **Balanced** keeps the springs but drops the 3D tilt, **Full** is the cinematic experience. Everything decorative is multiplied by this one setting.
- **Real performance work**: the aurora background now builds its gradients once per theme change instead of allocating a brush on every frame, the background is still moved by the GPU only, list rows keep a fixed content type so the lazy list reuses them, and there is a **Compact rows** mode that fits far more people on screen.
- **Animated scroll rail**: a thin glowing bar on the screen edge. It thickens while you scroll, shows your position and how much of the list is on screen, and you can **drag it to fly** through hundreds of contacts (with haptic ticks).
- **Back-to-top bubble** with a scroll-progress ring that springs in once you scroll down.
- **Letter headers** now show how many people are in each group.
- **Favourites filter chip** next to your tags, plus the search field now sinks and shrinks slightly as the header collapses.
- **T9 dial pad** (the phone icon in the header): type digits, it matches numbers *and* names (2 = ABC …), shows matching people live, then call or message straight from the pad.
- **Insights screen** (chart icon in the header): address-book health ring, animated stat tiles (contacts, favourites, with photo, no number, duplicates, tags), a **people-by-letter bar chart that grows in**, recently-in-touch list, upcoming birthdays and a tag cloud. Everything is computed on the device.
- **Responsive layout**: on tablets and foldables the list stays a comfortable column instead of stretching edge to edge.
- **Haptics toggle**: press, swipe, drag and rail ticks can all be silenced.

## What's new in 1.1 (speed + premium pass)
- **Optimized release build** (R8 shrinking + Compose baseline profile support). Debug APKs are several times slower; the workflow now builds the release APK, signed with the standard debug key so it installs normally.
- **Smooth scrolling**: rows no longer recompose while you scroll, the background is moved by the GPU instead of being redrawn, and one shared background serves every screen.
- **New scroll animation — "depth parallax"**: avatars and names slide at different speeds with your scroll velocity and settle with a soft spring, while rows at the screen edges tilt in 3D and fade.
- **New intro**: gradient ring draws itself, seven contacts orbit with comet trails, spiral into a glass core that becomes the contact mark, bloom, wordmark, then a circular reveal into the app.
- **Stay in touch**: starred or tagged people you have not talked to in 3 weeks, with one-tap call (uses the call log).
- **Last talked** time on every contact and a **Recent activity** call timeline on the contact page.
- **QR share**: show a contact as a QR code another phone's camera can save; the code blooms in module by module.
- **Message everyone with a tag** in one tap.

## What is inside (round 1)
- **Cinematic intro** (~4.5 s, tap to skip): letterbox bars, warp-speed streaks, a swarm of orbs spiralling in, core ignition with flash, camera shake and shockwave, the contact glyph drawing itself, title assembling letter by letter, then a dissolve into the app. Drawn live on a Canvas, with haptics.
- **Two designs**: *Aurora Night* (dark: glass, glow, living aurora light) and *Paper Studio* (light: warm paper, soft shadows, pastel light). Follows the system by default; switch System / Light / Dark in Settings; 6 accent palettes.
- **Contacts list**: sticky letter headers, 3D tilt/fade scroll effect at the screen edges, magnifying fast-scroll bar with a letter bubble, live search (name, number, email, company, **T9**) with highlighting, favorites carousel with animated rings, upcoming birthdays, swipe right to call / swipe left to message, long-press multi-select (star, delete), tag filters, live refresh when contacts change anywhere.
- **Contact page**: parallax hero, staggered action buttons (call, message, WhatsApp, email), tap-to-call/copy, star burst, share as vCard, local colour tags, delete with Undo.
- **New / edit contact**: live avatar with a completeness ring, floating-label fields with glow, check marks that pop when a number/email is valid, animated add/remove of phones and emails, birthday picker, photo from gallery, morphing Save button with confetti.
- **Cleanup centre**: address-book health score, duplicate finder with one-tap merge, contacts with no number or email.
- **Settings**: theme, accent, sort by last name, intro on/off, compact rows, animation level, haptics, scroll rail, insights, export every contact as a `.vcf` file.
- Works like the system Contacts app: handles view / edit / insert / pick contact intents.

## Notes
- Contacts are stored in the phone's own contact database, so other apps see the same data.
- Tags and settings are stored locally on the phone.
